# Índice — G1 (Ângulos)

| Folha | Unidade | Degrau novo |
|---|---|---|
| G1 1 | Reconhecer ângulos 1 | nomear ângulos e classificar valores (já existe) |
| G1 2 | Reconhecer ângulos 2 | classificar pela figura e listar ângulos de semirretas (já existe) |
| G1 3 | Reconhecer ângulos 3 | tipo a partir de uma conta; revisão de 1 a 3 (já existe) |
| G1 4 | Reconhecer ângulos 4 | sai a figura: vértice e lados são lidos só pelo nome do ângulo. |
| G1 5 | Reconhecer ângulos 5 | caminho inverso (do vértice e lados para o nome) e ângulos de figura perto do reto. |
| G1 6 | Reconhecer ângulos 6 | a volta inteira (360°) aparece: frações de volta viram graus. |
| G1 7 | Reconhecer ângulos 7 | o relógio: cada número vale 30°. |
| G1 8 | Reconhecer ângulos 8 | as fronteiras de cada tipo (89°, 91°, 179°) e afirmações gerais. |
| G1 9 | Reconhecer ângulos 9 | classificar e contar todos os ângulos de uma figura com 5 semirretas. |
| G1 10 | Reconhecer ângulos 10 | revisão de toda a unidade (nada novo). |
| G1 11 | Graus, minutos e segundos 1 | as unidades menores: 1° = 60' e 1' = 60". |
| G1 12 | Graus, minutos e segundos 2 | misturar graus e minutos nos dois sentidos. |
| G1 13 | Graus, minutos e segundos 3 | o mesmo vai e volta, agora entre minutos e segundos. |
| G1 14 | Graus, minutos e segundos 4 | graus com vírgula (decimais) e graus com minutos. |
| G1 15 | Graus, minutos e segundos 5 | somar, coluna por coluna, sem transporte. |
| G1 16 | Graus, minutos e segundos 6 | somar com transporte: 60" viram 1' e 60' viram 1°. |
| G1 17 | Graus, minutos e segundos 7 | subtrair, primeiro sem e depois com empréstimo. |
| G1 18 | Graus, minutos e segundos 8 | empréstimo em duas colunas, e o caso especial de 90° e 180° menos um ângulo. |
| G1 19 | Graus, minutos e segundos 9 | multiplicar por inteiro, com transporte. |
| G1 20 | Graus, minutos e segundos 10 | dividir por inteiro, com o resto descendo para minutos e segundos. |
| G1 21 | Complemento e suplemento 1 | complemento (falta para 90°) e suplemento (falta para 180°). |
| G1 22 | Complemento e suplemento 2 | complemento e suplemento de ângulos com minutos e segundos. |
| G1 23 | Complemento e suplemento 3 | o caminho de volta: dado o complemento ou o suplemento, achar o ângulo. |
| G1 24 | Complemento e suplemento 4 | duas operações encadeadas, de dentro para fora. |
| G1 25 | Complemento e suplemento 5 | a ordem importa: "dobro do complemento" é diferente de "complemento do dobro". |
| G1 26 | Complemento e suplemento 6 | quando existe complemento e o que são ângulos complementares e suplementares. |
| G1 27 | Complemento e suplemento 7 | o encadeamento com minutos e segundos. |
| G1 28 | Complemento e suplemento 8 | o bizu: o suplemento é sempre 90° maior que o complemento. |
| G1 29 | Complemento e suplemento 9 | expressões com três operações encadeadas. |
| G1 30 | Complemento e suplemento 10 | revisão de toda a unidade (nada novo). |
| G1 31 | Equações com ângulos 1 | equações simples; ângulos complementares escritos com x. |
| G1 32 | Equações com ângulos 2 | suplementares com x, e depois usar o x para achar o ângulo. |
| G1 33 | Equações com ângulos 3 | a frase vira equação: "o complemento de x" vira 90° − x. |
| G1 34 | Equações com ângulos 4 | o clássico: complemento e suplemento do mesmo x na mesma equação. |
| G1 35 | Equações com ângulos 5 | somas e diferenças: o x aparece em mais de um termo. |
| G1 36 | Equações com ângulos 6 | resposta que não é o x, e x que não dá inteiro (vira graus e minutos). |
| G1 37 | Equações com ângulos 7 | dois ângulos desconhecidos: um escrito em função do outro. |
| G1 38 | Equações com ângulos 8 | razão entre os dois ângulos (partes iguais de tamanho k). |
| G1 39 | Equações com ângulos 9 | equações em que um termo já é encadeado (suplemento do complemento). |
| G1 40 | Equações com ângulos 10 | revisão de toda a unidade (nada novo). |
| G1 41 | Posições 1 | ângulos lado a lado: o todo é a soma das partes. |
| G1 42 | Posições 2 | nomes das posições: consecutivos (lado comum) e adjacentes (lado comum sem sobrepor). |
| G1 43 | Posições 3 | bissetriz: a semirreta que divide o ângulo ao meio. |
| G1 44 | Posições 4 | bissetriz com expressões em x. |
| G1 45 | Posições 5 | duas retas que se cruzam: opostos iguais. |
| G1 46 | Posições 6 | retas que se cruzam com expressões em x. |
| G1 47 | Posições 7 | vários ângulos em sequência: somam 180° (reta) ou 360° (volta). |
| G1 48 | Posições 8 | duas bissetrizes ao mesmo tempo: o ângulo entre elas é a metade da soma. |
| G1 49 | Posições 9 | reconhecer sozinho qual posição usar (bissetriz, opostos, reta, volta). |
| G1 50 | Posições 10 | revisão de toda a unidade (nada novo). |
| G1 51 | Revisão 1 1 | mistura das unidades 1 e 2 (reconhecer; graus, minutos e segundos). |
| G1 52 | Revisão 1 2 | mistura das unidades 2 e 3, com minutos e segundos nos cálculos de complemento. |
| G1 53 | Revisão 1 3 | unidade 4 inteira misturada. |
| G1 54 | Revisão 1 4 | unidade 5 inteira misturada. |
| G1 55 | Revisão 1 5 | mistura das unidades 1 a 3, agora com figura. |
| G1 56 | Revisão 1 6 | a mesma conta nos dois sentidos: calcular direto e achar x a partir do resultado. |
| G1 57 | Revisão 1 7 | mistura das unidades 4 e 5: toda posição vira uma equação. |
| G1 58 | Revisão 1 8 | tudo de 1 a 50 misturado, em nível fácil. |
| G1 59 | Revisão 1 9 | tudo de 1 a 50 misturado, em nível médio. |
| G1 60 | Revisão 1 10 | tudo de 1 a 50 misturado, no nível mais alto antes das paralelas. |
| G1 61 | Paralelas: identificar 1 | duas paralelas e uma transversal: 8 ângulos numerados; correspondentes. |
| G1 62 | Paralelas: identificar 2 | alternos internos. |
| G1 63 | Paralelas: identificar 3 | alternos externos. |
| G1 64 | Paralelas: identificar 4 | colaterais internos. |
| G1 65 | Paralelas: identificar 5 | colaterais externos. |
| G1 66 | Paralelas: identificar 6 | todos os nomes juntos: reconhecer qualquer par. |
| G1 67 | Paralelas: identificar 7 | o que cada nome significa: ângulos iguais ou que somam 180°. |
| G1 68 | Paralelas: identificar 8 | as relações viram números: um ângulo dado, todos os outros saem. |
| G1 69 | Paralelas: identificar 9 | ver o quadro todo: os 8 ângulos têm só duas medidas. |
| G1 70 | Paralelas: identificar 10 | revisão de toda a unidade (nada novo). |
| G1 71 | Paralelas: calcular 1 | a relação vira equação: ângulos iguais, uma expressão e um valor. |
| G1 72 | Paralelas: calcular 2 | expressão dos dois lados da equação. |
| G1 73 | Paralelas: calcular 3 | colaterais: a equação agora é soma igual a 180°. |
| G1 74 | Paralelas: calcular 4 | a resposta é o ângulo, não o x: substituir x de volta. |
| G1 75 | Paralelas: calcular 5 | as mesmas contas para os pares externos. |
| G1 76 | Paralelas: calcular 6 | duas incógnitas na mesma figura. |
| G1 77 | Paralelas: calcular 7 | expressões com frações de x e respostas em graus e minutos. |
| G1 78 | Paralelas: calcular 8 | nenhum nome é dado: o aluno decide se os ângulos são iguais ou somam 180°. |
| G1 79 | Paralelas: calcular 9 | pares sem nome: chegar à relação passando por um terceiro ângulo. |
| G1 80 | Paralelas: calcular 10 | revisão de toda a unidade (nada novo). |
| G1 81 | O bizu dos bicos 1 | um bico: o ângulo do bico é a soma dos ângulos nas paralelas (já existe) |
| G1 82 | O bizu dos bicos 2 | um bico com valores menos redondos, x no bico e nas paralelas. |
| G1 83 | O bizu dos bicos 3 | o bico muda de lado (aponta para a esquerda); a regra é a mesma. |
| G1 84 | O bizu dos bicos 4 | a mesma regra com graus e minutos (soma e subtração da unidade 2). |
| G1 85 | O bizu dos bicos 5 | dois bicos: somas dos que abrem para cada lado são iguais (já existe) |
| G1 86 | O bizu dos bicos 6 | dois bicos na ordem contrária (o primeiro aponta para a esquerda) e valores quebrados. |
| G1 87 | O bizu dos bicos 7 | três bicos na mesma figura. |
| G1 88 | O bizu dos bicos 8 | a mesma letra em dois ângulos: x + x = 2x. |
| G1 89 | O bizu dos bicos 9 | expressões em x e questão de prova (já existe) |
| G1 90 | O bizu dos bicos 10 | fecha a unidade: um, dois e três bicos, minutos, x repetido e expressões misturados. |
| G1 91 | Questões de prova 1 | primeiro contato com o formato de prova (alternativas), em complemento e suplemento. |
| G1 92 | Questões de prova 2 | formato de prova com graus, minutos e segundos. |
| G1 93 | Questões de prova 3 | formato de prova em posições (bissetriz, opostos, ângulos sobre uma reta). |
| G1 94 | Questões de prova 4 | formato de prova em paralelas cortadas por transversal. |
| G1 95 | Questões de prova 5 | formato de prova no bizu dos bicos. |
| G1 96 | Questões de prova 6 | formato de prova misturando reconhecimento de ângulos com contas. |
| G1 97 | Questões de prova 7 | formato de prova com equações de mais de um termo. |
| G1 98 | Questões de prova 8 | formato de prova com figuras que pedem passar por um terceiro ângulo. |
| G1 99 | Questões de prova 9 | formato de prova com respostas em graus e minutos. |
| G1 100 | Questões de prova 10 | simulado final do nível: um pouco de cada unidade, no formato de prova. |

Nivelamento: `NIVELAMENTO_G1.md` (10 questões, uma por unidade).
