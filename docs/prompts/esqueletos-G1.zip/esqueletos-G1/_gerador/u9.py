from common import *
from u5 import ev
from u4 import solve
import math
U='O bizu dos bicos'
def ang_between(a,b):
    a%=360; b%=360; d=(b-a)%360
    return d if d<=180 else 360-d
def bico_vals(segs, ends):
    """segs: direções (Fraction, graus, todas apontando para baixo); ends: lado do ângulo marcado em r e em s ('dir'/'esq').
       devolve lista de ângulos: [em r, vértice 1, ..., em s]"""
    d=[Fr(x) for x in segs]
    vals=[]
    v0=ang_between(0,d[0]); vals.append(v0 if ends[0]=='dir' else 180-v0)
    for i in range(len(d)-1): vals.append(ang_between(d[i]+180,d[i+1]))
    vl=ang_between(0,d[-1]+180); vals.append(vl if ends[1]=='dir' else 180-vl)
    return vals
def checa_geometria(segs, L=15, gap=45):
    y=0
    for i,dd in enumerate(segs[:-1]):
        y+=L*math.sin(math.radians(float(dd)))
        assert -gap+4 < y < -2, ('vértice fora da faixa', segs)
    assert all(-178<float(x)<-2 for x in segs)
def dtxt(x):
    x=Fr(x); sg='−' if x<0 else ''
    c=fmt(deg(abs(x)))[0]
    return sg+(c+'°' if c.isdigit() else c)
def bico_fig(segs, ends, labels, L=15, gap=45):
    checa_geometria(segs,L,gap)
    n=len(segs)
    st=', '.join(f'{dtxt(dd)} ({L} mm)' for dd in segs[:-1])+f', {dtxt(segs[-1])} (até s)'
    nomes=[f'em r (início), lado {"direito" if ends[0]=="dir" else "esquerdo"}']+[f'no vértice {i}' for i in range(1,n)]+[f'em s (fim), lado {"direito" if ends[1]=="dir" else "esquerdo"}']
    esc='; '.join(f'{nm}: {lb}' for nm,lb in zip(nomes,labels))
    return f'bico entre paralelas: retas r (acima) e s (abaixo) horizontais, distância {gap} mm; poligonal começa em r; segmentos nas direções {st}; escrever {esc}'
def bico_item(segs, ends, xpos, enun='Ache x.', exprs=None, L=15):
    vals=bico_vals(segs,ends)
    labels=[]
    if exprs:  # exprs: dict pos->expressão em x; fecha com o mesmo x
        p0=next(iter(exprs)); x=solve(lambda x:ev(exprs[p0],x)-vals[p0])
        for p,e in exprs.items(): assert ev(e,x)==vals[p], (segs,p,e,x,vals[p])
        for i,v in enumerate(vals): labels.append(exprs.get(i, fmt_ang(v)))
        resp=x
    else:
        xs=[xpos] if isinstance(xpos,int) else list(xpos)
        if len(xs)>1: assert len({vals[i] for i in xs})==1, ('x repetido com valores diferentes',vals,xs)
        for i,v in enumerate(vals): labels.append('x' if i in xs else fmt_ang(v))
        resp=vals[xs[0]]
    return ang_item(enun, deg(resp), fig=bico_fig(segs,ends,labels,L))
def fmt_ang(v):
    c=fmt(deg(v))[0]; return c+'°' if c.isdigit() else c

R=lambda a,b:([-a, b-180],('dir','dir'))      # bico para a direita: em r ângulo a (lado dir), em s ângulo b (lado dir)
Lf=lambda a,b:([-(180-a), -b],('esq','esq'))   # bico para a esquerda
# 82
def it(segends,xpos): return bico_item(segends[0],segends[1],xpos)
a=page('um bico, valores quebrados, x no bico','Calcule x.  (r // s)',[it(R(37,48),1),it(R(26,59),1),it(R(43,44),1),it(R(18,67),1)])
b=page('um bico, x numa das paralelas','Calcule x.  (r // s)',[it(R(41,53),0),it(R(29,66),2),it(R(52,31),0),it(R(34,47),2)])
folha(82,U,2,'um bico com valores menos redondos, x no bico e nas paralelas.',a,b)
# 83
a=page('bico virado para a esquerda, x no bico','Calcule x.  (r // s)',[it(Lf(35,40),1),it(Lf(27,51),1),it(Lf(46,38),1),it(Lf(22,63),1)],
  exemplo='Bico para a esquerda: a mesma regra. Em r 30°, em s 40° → x = 70°.')
b=page('bico para a esquerda, x na paralela','Calcule x.  (r // s)',[it(Lf(33,49),0),it(Lf(58,24),2),it(Lf(19,61),0),it(Lf(44,36),2)])
folha(83,U,3,'o bico muda de lado (aponta para a esquerda); a regra é a mesma.',a,b)
# 84
def Rd(a,b): return ([-a, b-180],('dir','dir'))
def Ld(a,b): return ([-(180-a), -b],('esq','esq'))
h=lambda d,m=0: Fr(d)+Fr(m,60)
a=page('um bico com graus e minutos','Calcule x.  (r // s)',[it(Rd(h(35,30),h(42,45)),1),it(Ld(h(28,15),h(51,50)),1),it(Rd(h(40,20),h(33,40)),1),it(Ld(h(47,45),h(25,30)),1)],
  exemplo="Em r 35°30', em s 42°45': x = 35°30' + 42°45' = 78°15'.")
b=page('um bico com minutos, x na paralela','Calcule x.  (r // s)',[it(Rd(h(36,40),h(44,50)),0),it(Ld(h(31,25),h(48,15)),2),it(Rd(h(25,45),h(55,30)),2),it(Ld(h(52,10),h(29,35)),0)])
folha(84,U,4,'a mesma regra com graus e minutos (soma e subtração da unidade 2).',a,b)

# 86, 87: dois e três bicos
def two(d1,d2,d3,ends): return ([d1,d2,d3],ends)
a=page('dois bicos começando para a esquerda','Calcule x.  (r // s)',[
  it(two(-145,-28,-130,('esq','dir')),1), it(two(-152,-35,-140,('esq','dir')),2), it(two(-138,-22,-125,('esq','dir')),0), it(two(-150,-40,-135,('esq','dir')),3)],
  exemplo='Some os que abrem para a esquerda e iguale à soma dos que abrem para a direita.')
b=page('dois bicos, valores quebrados','Calcule x.  (r // s)',[
  it(two(-23,-147,-38,('dir','esq')),1), it(two(-31,-158,-44,('dir','esq')),2), it(two(-142,-27,-133,('esq','dir')),3), it(two(-17,-139,-52,('dir','esq')),0)])
folha(86,U,6,'dois bicos na ordem contrária (o primeiro aponta para a esquerda) e valores quebrados.',a,b)

def three(d,ends): return (d,ends)
a=page('três bicos','Calcule x.  (r // s)',[
  it(three([-25,-150,-35,-145],('dir','dir')),2), it(three([-30,-155,-40,-140],('dir','dir')),1), it(three([-20,-145,-30,-150],('dir','dir')),4), it(three([-35,-160,-25,-135],('dir','dir')),3)],
  exemplo='Três bicos: abrem para a esquerda os bicos que apontam para a direita; os outros abrem para a direita. As duas somas são iguais.')
b=page('três bicos, x em qualquer posição','Calcule x.  (r // s)',[
  it(three([-155,-32,-148,-41],('esq','esq')),2), it(three([-28,-143,-37,-152],('dir','dir')),0), it(three([-147,-26,-139,-33],('esq','esq')),4), it(three([-33,-158,-24,-141],('dir','dir')),1)])
folha(87,U,7,'três bicos na mesma figura.',a,b)

# 88: x aparece duas vezes
a=page('o x aparece duas vezes','Calcule x.  (r // s)',[
  it(R(35,35),(0,2)), it(Lf(42,42),(0,2)), it(R(27,27),(0,2)), it(Lf(38,38),(0,2))],
  exemplo='Em r x, em s x, no bico 70°: x + x = 70° → x = 35°.')
b=page('dois bicos com x duas vezes','Calcule x.  (r // s)',[
  it(two(-30,-150,-30,('dir','esq')),(0,3)), it(two(-25,-155,-25,('dir','esq')),(0,3)), it(two(-145,-35,-145,('esq','dir')),(0,3)), it(two(-40,-140,-40,('dir','esq')),(0,3))])
folha(88,U,8,'a mesma letra em dois ângulos: x + x = 2x.',a,b)

# 90: misturado
a=page('mistura da unidade','Calcule x.  (r // s)',[
  it(R(39,46),1), it(Ld(h(30,30),h(44,45)),1), it(two(-27,-152,-41,('dir','esq')),2), it(three([-26,-148,-34,-151],('dir','dir')),3)])
b=page('mistura com expressões','Calcule x.  (r // s)',[
  bico_item([-30,-130],('dir','dir'),None,exprs={0:'x + 10°',1:'4x',2:'2x + 10°'}),
  bico_item([-25,-150,-40],('dir','esq'),None,exprs={0:'2x + 5°',1:'5x + 5°',2:'7x',3:'4x'}),
  bico_item([-150,-32,-145],('esq','dir'),None,exprs={0:'3x + 9°',1:'9x − 1°',2:'10x − 3°',3:'5x'}),
  bico_item([-35,-135],('dir','dir'),None,exprs={0:'x',1:'2x + 10°',2:'x + 10°'})])
folha(90,U,10,'fecha a unidade: um, dois e três bicos, minutos, x repetido e expressões misturados.',a,b)
