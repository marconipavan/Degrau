from common import *
U='Graus, minutos e segundos'
def disp(sec):
    c=fmt(sec)[0]; return c+'°' if c.isdigit() else c
def ms_item(enun, sec):
    d,m,s=dms_parts(sec); assert d==0
    if s==0: return item(enun,f"{m}'",[f"0°{m}'",f"{m}'0\""])
    return item(enun,f"{m}'{s}\"",[f"0°{m}'{s}\"",f"{m}'{s:02d}\""])
def dec_item(enun,x):
    t=num(x); return item(enun,t,[t.replace(',','.'),t+'°',t.replace(',','.')+'°'])

# 11
a=page('converter graus em minutos','Quantos minutos há em cada ângulo?',
  [item(f'{g}°',str(60*g),[f"{60*g}'"]) for g in [1,2,3,4,5,6,10,12,15,20]],
  exemplo="1° = 60'. Então 3° = 3 × 60' = 180'.")
b=page('converter minutos em segundos','Quantos segundos há em cada medida?',
  [item(f"{m}'",str(60*m),[f'{60*m}"']) for m in [1,2,3,4,5,6,10,12,15,30]],
  exemplo="1' = 60\". Então 2' = 2 × 60\" = 120\".")
folha(11,U,1,"as unidades menores: 1° = 60' e 1' = 60\".",a,b)

# 12
gm=[(1,20),(2,30),(3,5),(10,10),(1,1),(2,45),(5,15),(0,50),(12,12),(6,40)]
a=page('graus e minutos para minutos','Escreva tudo em minutos.',
  [item(disp(S(g,m)),str(60*g+m),[f"{60*g+m}'"]) for g,m in gm],
  exemplo="2°15' = 2 × 60' + 15' = 135'.")
mins=[75,130,200,61,90,150,121,300,59,245]
b=page('minutos para graus e minutos','Escreva em graus e minutos.',
  [ang_item(f"{m}'",S(0,m)) for m in mins],
  exemplo="135' = 120' + 15' = 2°15'.")
folha(12,U,2,'misturar graus e minutos nos dois sentidos.',a,b)

# 13
ms=[(2,10),(1,1),(3,30),(10,5),(1,59),(4,20),(6,6),(2,2),(12,30),(5,45)]
a=page('minutos e segundos para segundos','Escreva tudo em segundos.',
  [item(f"{m}'{s}\"",str(60*m+s),[f'{60*m+s}"']) for m,s in ms],
  exemplo="2'10\" = 2 × 60\" + 10\" = 130\".")
secs=[75,135,200,61,90,150,121,245,119,600]
b=page('segundos para minutos e segundos','Escreva em minutos e segundos.',
  [ms_item(f'{s}"',S(0,0,s)) for s in secs],
  exemplo="135\" = 120\" + 15\" = 2'15\".")
folha(13,U,3,'o mesmo vai e volta, agora entre minutos e segundos.',a,b)

# 14
decs=['30.5','12.25','45.1','10.75','0.5','60.2','7.6','22.4','1.05','89.9']
a=page('graus decimais para graus e minutos','Escreva em graus e minutos.',
  [ang_item(f"{num(Fr(d))}°",deg(Fr(d))) for d in decs],
  exemplo="30,5° = 30° + 0,5 × 60' = 30°30'.")
gm2=[(20,30),(15,45),(40,12),(7,6),(3,15),(10,3),(50,48),(1,30),(12,54),(0,6)]
b=page('graus e minutos para graus decimais','Escreva em graus com vírgula.',
  [dec_item(disp(S(g,m)),Fr(g)+Fr(m,60)) for g,m in gm2],
  exemplo="20°15' = 20° + 15/60 de grau = 20,25°.")
folha(14,U,4,'graus com vírgula (decimais) e graus com minutos.',a,b)

def soma(x,y): return x+y
# 15
p15=[((20,15),(30,20)),((12,10),(5,40)),((45,5),(10,50)),((8,30),(1,25)),((60,12),(20,7)),
     ((33,33),(11,11)),((90,0),(0,45)),((14,20),(14,20)),((5,5),(50,50)),((71,18),(8,41))]
a=page('somar graus e minutos sem passar de 60','Some os ângulos.',
  [ang_item(f"{disp(S(*x))} + {disp(S(*y))}",S(*x)+S(*y)) for x,y in p15],
  exemplo="20°15' + 30°20' = 50°35' (graus com graus, minutos com minutos).")
p15b=[((10,20,15),(5,10,30)),((22,5,5),(3,40,50)),((40,30,20),(10,10,10)),((7,0,45),(12,25,10)),((1,1,1),(2,2,2))]
b=page('somar com segundos, sem passar de 60','Some os ângulos.',
  [ang_item(f"{disp(S(*x))} + {disp(S(*y))}",S(*x)+S(*y)) for x,y in p15b],
  exemplo="10°20'15\" + 5°10'30\" = 15°30'45\".")
folha(15,U,5,'somar, coluna por coluna, sem transporte.',a,b)

# 16
p16=[((20,45),(10,30)),((12,50),(7,20)),((35,40),(4,40)),((8,59),(1,1)),((60,35),(29,25)),
     ((15,45),(15,45)),((70,30),(19,45)),((44,44),(10,20)),((5,55),(5,55)),((88,10),(1,50))]
a=page("somar com transporte dos minutos","Some os ângulos (60' viram 1°).",
  [ang_item(f"{disp(S(*x))} + {disp(S(*y))}",S(*x)+S(*y)) for x,y in p16],
  exemplo="20°45' + 10°30' = 30°75' = 31°15'.")
p16b=[((12,40,50),(7,30,20)),((30,0,45),(10,0,30)),((5,59,59),(0,0,1)),((45,25,40),(14,34,20)),((20,50,30),(9,20,45))]
b=page("somar com transporte dos segundos e minutos","Some os ângulos.",
  [ang_item(f"{disp(S(*x))} + {disp(S(*y))}",S(*x)+S(*y)) for x,y in p16b],
  exemplo="12°40'50\" + 7°30'20\" = 19°70'70\" = 19°71'10\" = 20°11'10\".")
folha(16,U,6,'somar com transporte: 60\" viram 1\' e 60\' viram 1°.',a,b)

# 17
p17=[((50,40),(20,15)),((80,55),(30,25)),((45,30),(15,30)),((90,50),(0,25)),((33,47),(11,12)),
     ((60,20),(60,5)),((100,45),(50,40)),((27,59),(7,9)),((12,30),(2,30)),((75,35),(25,15))]
a=page('subtrair sem empréstimo','Subtraia os ângulos.',
  [ang_item(f"{disp(S(*x))} − {disp(S(*y))}",S(*x)-S(*y)) for x,y in p17],
  exemplo="50°40' − 20°15' = 30°25'.")
p17b=[((50,10),(20,45)),((90,0),(35,20)),((180,0),(100,30)),((40,5),(10,50)),((90,0),(0,1)),
      ((61,15),(30,40)),((180,0),(45,45)),((90,0),(89,59)),((25,0),(12,30)),((100,20),(40,35))]
b=page("subtrair com empréstimo (1° vira 60')","Subtraia os ângulos.",
  [ang_item(f"{disp(S(*x))} − {disp(S(*y))}",S(*x)-S(*y)) for x,y in p17b],
  exemplo="90° − 35°20' = 89°60' − 35°20' = 54°40'.")
folha(17,U,7,'subtrair, primeiro sem e depois com empréstimo.',a,b)

# 18
p18=[((30,20,10),(10,30,40)),((45,0,0),(20,10,30)),((12,5,5),(6,10,10)),((60,30,15),(30,30,30)),((50,0,20),(25,30,40))]
a=page('subtrair com segundos e empréstimo','Subtraia os ângulos.',
  [ang_item(f"{disp(S(*x))} − {disp(S(*y))}",S(*x)-S(*y)) for x,y in p18],
  exemplo="30°20'10\" − 10°30'40\" = 29°79'70\" − 10°30'40\" = 19°49'30\".")
p18b=[((90,0,0),(25,35,40)),((180,0,0),(100,20,30)),((90,0,0),(45,0,1)),((180,0,0),(179,59,59)),((90,0,0),(12,12,12))]
b=page('90° e 180° menos um ângulo com segundos','Subtraia os ângulos.',
  [ang_item(f"{disp(S(*x))} − {disp(S(*y))}",S(*x)-S(*y)) for x,y in p18b],
  exemplo="90° − 25°35'40\" = 89°59'60\" − 25°35'40\" = 64°24'20\".")
folha(18,U,8,'empréstimo em duas colunas, e o caso especial de 90° e 180° menos um ângulo.',a,b)

# 19
p19=[(2,(15,20)),(3,(10,25)),(2,(40,45)),(4,(12,15)),(5,(10,12)),(3,(20,40)),(2,(45,30)),(6,(10,10)),(4,(22,30)),(3,(33,33))]
a=page('multiplicar graus e minutos por inteiro','Multiplique.',
  [ang_item(f"{k} × {disp(S(*x))}",k*S(*x)) for k,x in p19],
  exemplo="3 × 10°25' = 30°75' = 31°15'.")
p19b=[(2,(12,30,40)),(3,(10,20,30)),(4,(5,15,15)),(2,(44,44,44)),(5,(6,6,12))]
b=page('multiplicar com segundos','Multiplique.',
  [ang_item(f"{k} × {disp(S(*x))}",k*S(*x)) for k,x in p19b],
  exemplo="2 × 12°30'40\" = 24°60'80\" = 24°61'20\" = 25°1'20\".")
folha(19,U,9,'multiplicar por inteiro, com transporte.',a,b)

# 20
p20=[((40,20),2),((25,0),2),((50,10),2),((31,0),2),((90,0),2),((60,30),3),((100,0),4),((45,0),2),((15,0),4),((1,0),2)]
a=page('dividir por inteiro (sobra de grau vira minuto)','Divida.',
  [ang_item(f"{disp(S(*x))} ÷ {k}",S(*x)/k) for x,k in p20],
  exemplo="25° ÷ 2 = 24°60' ÷ 2 = 12°30'.")
p20b=[((25,15),2),((100,0),3),((45,15),2),((10,0),3),((1,0),4)]
b=page('dividir com minutos e segundos','Divida.',
  [ang_item(f"{disp(S(*x))} ÷ {k}",S(*x)/k) for x,k in p20b],
  exemplo="25°15' ÷ 2 = 24°75' ÷ 2 = 12°37'30\".")
folha(20,U,10,'dividir por inteiro, com o resto descendo para minutos e segundos.',a,b)
