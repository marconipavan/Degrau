from common import *
U='Reconhecer ângulos'
H='\u0302'
def nm(P,V,Q): return f'{P}{V}{H}{Q}'
def nome_item(enun,P,V,Q,fig=None):
    return item(enun, f'{P}{V}{Q}', [f'{Q}{V}{P}', nm(P,V,Q), nm(Q,V,P)], fig)
def fig_ang(V,P,dP,Q,dQ,marca='arco',valor=None):
    t=f"ângulo de vértice {V}, ponta {P} na direção {dP}°, ponta {Q} na direção {dQ}°; marca de {'ângulo reto' if marca=='reto' else 'arco'}"
    t+= f"; escrever {valor} na figura" if valor else "; sem valor escrito"
    return t

# ---- G1 4 ----
nomes=[('A','B','C'),('D','E','F'),('M','N','P'),('R','S','T'),('X','Y','Z'),('G','H','I'),('J','K','L'),('P','Q','R'),('U','V','W'),('B','O','C')]
a=page('identificar o vértice pelo nome','Escreva o vértice de cada ângulo.',
  [item(f'Vértice do ângulo {nm(*t)}', t[1]) for t in nomes],
  exemplo=f'No ângulo {nm("A","O","B")}, o vértice é O (a letra do meio, com o chapéu).')
lados=[('D','E','F'),('M','N','P'),('A','C','B'),('R','O','S'),('X','Y','Z')]
b=page('identificar os lados pelo nome','Escreva os dois lados de cada ângulo.',
  [item(f'Lados do ângulo {nm(*t)}', f'{t[1]}{t[0]}, {t[1]}{t[2]}', [f'{t[1]}{t[2]}, {t[1]}{t[0]}'], conjunto=True) for t in lados],
  exemplo=f'Ângulo {nm("A","O","B")}: lados OA e OB (cada lado começa no vértice).')
folha(4,U,4,'sai a figura: vértice e lados são lidos só pelo nome do ângulo.',a,b)

# ---- G1 5 ----
dados=[('B','A','C'),('E','D','F'),('Q','P','R'),('O','M','N'),('Y','X','Z'),('K','J','L'),('T','S','U'),('O','A','D'),('H','G','I'),('C','B','D')]
a=page('escrever o nome a partir do vértice e dos lados','Escreva o nome do ângulo.',
  [nome_item(f'Vértice {V}, lados {V}{P} e {V}{Q}',P,V,Q) for V,P,Q in dados],
  exemplo=f'Vértice O, lados OA e OB → ângulo {nm("A","O","B")} (ou {nm("B","O","A")}).')
figs=[(0,80,'A'),(0,100,'O'),(20,110,'R'),(0,150,'O'),(-20,55,'A')]
b=page('classificar pela figura, ângulos perto de 90°','Classifique cada ângulo: A, R ou O.',
  [cls_item(f'Ângulo {i+1} da figura', d2-d1, fig=fig_ang('O','A',d1,'B',d2,'reto' if c=='R' else 'arco')) for i,(d1,d2,c) in enumerate(figs)])
folha(5,U,5,'caminho inverso (do vértice e lados para o nome) e ângulos de figura perto do reto.',a,b)

# ---- G1 6 ----
fr=[(1,4),(1,2),(1,3),(1,6),(1,8),(1,12),(3,4),(2,3),(1,36),(1,360)]
a=page('fração de volta em graus','Quanto mede cada fração de volta?',
  [ang_item(f'{p}/{q} de volta', deg(Fr(360*p,q))) for p,q in fr],
  exemplo='Uma volta inteira mede 360°. Meia volta: 360° ÷ 2 = 180°.')
fr2=[(1,4),(1,3),(1,5),(1,2),(1,8),(3,8),(1,6),(5,12),(2,8),(1,10)]
b=page('classificar fração de volta','Classifique: A, R, O ou Ra.',
  [cls_item(f'{p}/{q} de volta', Fr(360*p,q)) for p,q in fr2])
folha(6,U,6,'a volta inteira (360°) aparece: frações de volta viram graus.',a,b)

# ---- G1 7 ----
def relogio(h): a=(30*h)%360; return min(a,360-a)
hs=[3,1,2,4,6,9,5,10,11,8]
a=page('ângulo entre os ponteiros em hora cheia','Menor ângulo entre os ponteiros do relógio.',
  [ang_item(f'{h} h em ponto', deg(relogio(h))) for h in hs],
  exemplo='De um número ao seguinte do relógio: 360° ÷ 12 = 30°. Às 2 h: 2 × 30° = 60°.')
hs2=[3,2,5,6,8,1,4,9,7,11]
b=page('classificar o ângulo do relógio','Classifique o menor ângulo: A, R, O ou Ra.',
  [cls_item(f'{h} h em ponto', relogio(h)) for h in hs2])
folha(7,U,7,'o relógio: cada número vale 30°.',a,b)

# ---- G1 8 ----
a=page('limites de cada tipo (resposta numérica)','Responda com um número inteiro de graus.',[
  ang_item('Maior ângulo agudo (medida inteira)',deg(89)),
  ang_item('Menor ângulo obtuso (medida inteira)',deg(91)),
  ang_item('Maior ângulo obtuso (medida inteira)',deg(179)),
  ang_item('Medida do ângulo reto',deg(90)),
  ang_item('Medida do ângulo raso',deg(180)),
  ang_item('Um reto dividido ao meio: quanto mede cada parte?',deg(45)),
  ang_item('Um raso dividido em 3 partes iguais: cada parte?',deg(60)),
  ang_item('Dois retos juntos medem quanto?',deg(180)),
  ang_item('Metade de um ângulo raso',deg(90)),
  ang_item('Menor ângulo agudo (medida inteira)',deg(1))])
b=page('verdadeiro ou falso sobre os tipos','Responda S (sim) ou N (não).',[
  sn_item('Todo ângulo de 90° é reto?',True),
  sn_item('Existe ângulo obtuso de 180°?',False),
  sn_item('A soma de dois agudos pode ser obtusa?',True),
  sn_item('A soma de dois agudos pode ser rasa?',False),
  sn_item('A metade de um obtuso é sempre aguda?',True),
  sn_item('O dobro de um reto é raso?',True),
  sn_item('O triplo de um agudo é sempre obtuso?',False),
  sn_item('Obtuso menos reto dá sempre agudo?',True),
  sn_item('Um ângulo de 90,5° é agudo?',False),
  sn_item('Dois ângulos retos juntos formam um raso?',True)])
folha(8,U,8,'as fronteiras de cada tipo (89°, 91°, 179°) e afirmações gerais.',a,b)

# ---- G1 9 ----
F9='semirretas de mesma origem O: A 0°, B 30°, C 90°, D 150°, E 180°; marca de ângulo reto entre A e C; sem valores escritos'
pares=[('A','B',30),('A','C',90),('A','D',150),('A','E',180),('B','C',60),('B','D',120),('B','E',150),('C','D',60),('C','E',90),('D','E',30)]
a=page('classificar ângulos numa figura com várias semirretas','Classifique cada ângulo da figura: A, R, O ou Ra.',
  [cls_item(f'Ângulo {nm(P,"O",Q)}',v,fig=F9 if i==0 else 'a mesma figura') for i,(P,Q,v) in enumerate(pares)])
cont={'A':0,'R':0,'O':0,'Ra':0}
for *_,v in pares: cont[classif(v)]+=1
b=page('contar ângulos de cada tipo','Na figura, conte os ângulos de cada tipo.',[
  item('Quantos ângulos agudos?',cont['A'],fig=F9),
  item('Quantos ângulos retos?',cont['R'],fig='a mesma figura'),
  item('Quantos ângulos obtusos?',cont['O'],fig='a mesma figura'),
  item('Quantos ângulos rasos?',cont['Ra'],fig='a mesma figura'),
  item('Quantos ângulos ao todo?',len(pares),fig='a mesma figura')])
folha(9,U,9,'classificar e contar todos os ângulos de uma figura com 5 semirretas.',a,b)

# ---- G1 10 ----
a=page('revisão da unidade','Revisão: responda no caderno.',[
  item(f'Vértice do ângulo {nm("M","N","P")}','N'),
  nome_item('Vértice Q, lados QR e QS','R','Q','S'),
  ang_item('1/3 de volta',deg(120)),
  ang_item('Menor ângulo dos ponteiros às 4 h',deg(120)),
  ang_item('Maior ângulo agudo (medida inteira)',deg(89)),
  cls_item('Classifique 135°',135),
  cls_item('Classifique 3/8 de volta',135),
  cls_item('Classifique o menor ângulo às 6 h',180),
  sn_item('A metade de um raso é reta?',True),
  item('Quantos ângulos formam 4 semirretas de mesma origem?',6)])
F10='semirretas de mesma origem O: A 0°, B 45°, C 90°, D 180°; marca de ângulo reto entre A e C; sem valores escritos'
b=page('revisão com figura','Revisão: responda olhando a figura.',[
  cls_item(f'Tipo de {nm("A","O","B")}',45,fig=F10),
  cls_item(f'Tipo de {nm("A","O","C")}',90,fig='a mesma figura'),
  cls_item(f'Tipo de {nm("B","O","D")}',135,fig='a mesma figura'),
  cls_item(f'Tipo de {nm("A","O","D")}',180,fig='a mesma figura'),
  item('Quantos ângulos há na figura?',6,fig='a mesma figura'),
  item('Quantos deles são agudos?',2,fig='a mesma figura'),
  item(f'Lados do ângulo {nm("B","O","C")}','OB, OC',['OC, OB'],fig='a mesma figura',conjunto=True),
  item('Qual ângulo da figura é raso? (nome)','AOD',['DOA',nm('A','O','D'),nm('D','O','A')],fig='a mesma figura'),
  item('Quantos ângulos retos há na figura?',2,fig='a mesma figura'),
  item('Quantos ângulos obtusos há na figura?',1,fig='a mesma figura')])
folha(10,U,10,'revisão de toda a unidade (nada novo).',a,b)
