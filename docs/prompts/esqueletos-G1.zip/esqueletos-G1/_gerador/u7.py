from common import *
U='Paralelas: identificar'
POS={1:('r','acima à direita'),2:('r','acima à esquerda'),3:('r','abaixo à esquerda'),4:('r','abaixo à direita'),
     5:('s','acima à direita'),6:('s','acima à esquerda'),7:('s','abaixo à esquerda'),8:('s','abaixo à direita')}
def valor(n,d): d=Fr(str(d).replace(',','.')) if isinstance(d,str) else d; return d if n in (1,3,5,7) else 180-d
def fig_par(d, escr=None):
    """escr: dict número -> texto; padrão: escrever os números 1 a 8"""
    escr=escr or {n:str(n) for n in POS}
    t=f'retas r (acima) e s (abaixo) horizontais e paralelas; transversal t com direção {d}°; escrever: '
    return t+'; '.join(f'em {POS[n][0]}, {POS[n][1]}: {escr[n]}' for n in sorted(escr))+('' if len(escr)==8 else '; nos outros, nada')
TIPO={}
for p in [(1,5),(2,6),(3,7),(4,8)]: TIPO[frozenset(p)]='CO'
for p in [(3,5),(4,6)]: TIPO[frozenset(p)]='AI'
for p in [(1,7),(2,8)]: TIPO[frozenset(p)]='AE'
for p in [(3,6),(4,5)]: TIPO[frozenset(p)]='CI'
for p in [(2,7),(1,8)]: TIPO[frozenset(p)]='CE'
for p in [(1,3),(2,4),(5,7),(6,8)]: TIPO[frozenset(p)]='OV'
for p in [(1,2),(2,3),(3,4),(1,4),(5,6),(6,7),(7,8),(5,8)]: TIPO[frozenset(p)]='LL'
def tipo(a,b): return TIPO.get(frozenset((a,b)),'NA')
NOMES={'CO':'correspondentes','AI':'alternos internos','AE':'alternos externos','CI':'colaterais internos','CE':'colaterais externos','OV':'opostos pelo vértice','LL':'lado a lado'}
def par_de(n,t):
    for k,v in TIPO.items():
        if v==t and n in k: return (set(k)-{n}).pop()
def ask_par(d,t,ns,nome):
    return [item(f'O {nome} do ângulo {n}', str(par_de(n,t)), fig=fig_par(d) if i==0 else 'a mesma figura') for i,n in enumerate(ns)]
def sn_pares(d,t,pares):
    return [sn_item(f'{a} e {b} são {NOMES[t]}?', tipo(a,b)==t) if True else None for a,b in pares][:10]
def sn_pares_fig(d,t,pares):
    its=sn_pares(d,t,pares); its[0]['fig']=fig_par(d)
    for it in its[1:]: it['fig']='a mesma figura'
    return its

# 61
a=page('achar o correspondente','Escreva o número do ângulo correspondente.',ask_par(60,'CO',[1,2,3,4],'correspondente'),
  exemplo='Correspondentes ocupam a mesma posição em cada cruzamento: 1 (em r, acima à direita) e 5 (em s, acima à direita).')
b=page('reconhecer pares correspondentes','São correspondentes? Responda S ou N.',
  sn_pares_fig(120,'CO',[(2,6),(1,6),(4,8),(3,5),(3,7),(1,5),(2,8),(5,1),(4,7),(6,2)]))
folha(61,U,1,'duas paralelas e uma transversal: 8 ângulos numerados; correspondentes.',a,b)

# 62
a=page('achar o alterno interno','Escreva o número do alterno interno.',ask_par(55,'AI',[3,4,5,6],'alterno interno'),
  exemplo='Alternos internos: entre as paralelas e em lados opostos da transversal: 3 e 5.')
b=page('reconhecer alternos internos','São alternos internos? Responda S ou N.',
  sn_pares_fig(125,'AI',[(3,5),(4,6),(3,6),(4,5),(1,7),(5,3),(2,6),(6,4),(3,7),(4,8)]))
folha(62,U,2,'alternos internos.',a,b)

# 63
a=page('achar o alterno externo','Escreva o número do alterno externo.',ask_par(65,'AE',[1,2,7,8],'alterno externo'),
  exemplo='Alternos externos: fora das paralelas e em lados opostos da transversal: 1 e 7.')
b=page('reconhecer alternos externos','São alternos externos? Responda S ou N.',
  sn_pares_fig(110,'AE',[(1,7),(2,8),(1,8),(2,7),(3,5),(7,1),(1,5),(8,2),(4,6),(2,6)]))
folha(63,U,3,'alternos externos.',a,b)

# 64
a=page('achar o colateral interno','Escreva o número do colateral interno.',ask_par(50,'CI',[3,4,5,6],'colateral interno'),
  exemplo='Colaterais internos: entre as paralelas e do mesmo lado da transversal: 4 e 5.')
b=page('reconhecer colaterais internos','São colaterais internos? Responda S ou N.',
  sn_pares_fig(130,'CI',[(4,5),(3,6),(3,5),(4,6),(5,4),(2,7),(6,3),(1,8),(3,4),(5,6)]))
folha(64,U,4,'colaterais internos.',a,b)

# 65
a=page('achar o colateral externo','Escreva o número do colateral externo.',ask_par(70,'CE',[1,2,7,8],'colateral externo'),
  exemplo='Colaterais externos: fora das paralelas e do mesmo lado da transversal: 1 e 8.')
b=page('reconhecer colaterais externos','São colaterais externos? Responda S ou N.',
  sn_pares_fig(115,'CE',[(1,8),(2,7),(1,7),(2,8),(8,1),(4,5),(7,2),(3,6),(1,5),(2,6)]))
folha(65,U,5,'colaterais externos.',a,b)

# 66
ACE={k:[v] for k,v in NOMES.items()}
def cls_pares(d,pares):
    its=[]
    for i,(a1,b1) in enumerate(pares):
        t=tipo(a1,b1); assert t!='NA',(a1,b1)
        its.append(item(f'{a1} e {b1}',t,ACE[t],fig=fig_par(d) if i==0 else 'a mesma figura'))
    return its
a=page('dar o nome do par','Escreva o tipo: CO, AI, AE, CI ou CE.',
  cls_pares(60,[(1,5),(3,5),(1,7),(3,6),(2,7),(4,8),(4,6),(2,8),(4,5),(1,8)]),
  exemplo='CO = correspondentes; AI/AE = alternos internos/externos; CI/CE = colaterais internos/externos.')
b=page('dar o nome do par, incluindo opostos e lado a lado','Tipo: CO, AI, AE, CI, CE, OV ou LL.',
  cls_pares(125,[(1,3),(2,6),(5,6),(3,5),(6,8),(1,8),(7,8),(4,5),(2,4),(1,7)]),
  exemplo='OV = opostos pelo vértice (1 e 3); LL = lado a lado no mesmo cruzamento (1 e 2).')
folha(66,U,6,'todos os nomes juntos: reconhecer qualquer par.',a,b)

# 67
def cs(a1,b1,d):
    return 'C' if valor(a1,d)==valor(b1,d) else 'S'
def cs_pares(d,pares):
    its=[]
    for i,(a1,b1) in enumerate(pares):
        k=cs(a1,b1,d); assert d!=90
        its.append(item(f'{a1} e {b1}',k,['congruentes' if k=='C' else 'suplementares'],fig=fig_par(d) if i==0 else 'a mesma figura'))
    return its
a=page('congruentes ou suplementares','Os ângulos são iguais (C) ou somam 180° (S)?',
  cs_pares(65,[(1,5),(3,5),(3,6),(1,7),(4,5),(2,6),(2,7),(4,6),(1,8),(2,8)]),
  exemplo='Correspondentes e alternos são iguais (C); colaterais somam 180° (S).')
b=page('congruentes ou suplementares, qualquer par','Iguais (C) ou somam 180° (S)?',
  cs_pares(120,[(1,3),(1,2),(5,8),(2,8),(6,7),(3,8),(1,6),(4,7),(2,5),(7,3)]))
folha(67,U,7,'o que cada nome significa: ângulos iguais ou que somam 180°.',a,b)

# 68
def val_items(d,dado,pedidos):
    escr={dado:f'{valor(dado,d)}°'}
    for p in pedidos: escr[p]=str(p)
    return [ang_item(f'Quanto mede o ângulo {p}?',deg(valor(p,d)),fig=fig_par(d,escr) if i==0 else 'a mesma figura') for i,p in enumerate(pedidos)]
a=page('achar medidas a partir de um ângulo dado','O ângulo 1 mede 70°. Calcule os pedidos.',val_items(70,1,[5,3,2,8,6]),
  exemplo='1 mede 70°: 5 (correspondente) mede 70°; 2 (lado a lado) mede 110°.')
b=page('achar medidas a partir de outro ângulo','O ângulo 4 mede 115°. Calcule os pedidos.',val_items(65,4,[6,2,1,7,5]))
folha(68,U,8,'as relações viram números: um ângulo dado, todos os outros saem.',a,b)

# 69
def conj(n,d):
    s=[m for m in POS if m!=n and valor(m,d)==valor(n,d)]
    return item(f'Ângulos iguais ao ângulo {n}', ', '.join(map(str,s)), conjunto=True)
a=page('achar todos os ângulos iguais a um dado','Liste todos os ângulos iguais ao indicado.',[conj(1,60),conj(2,60),conj(6,60),conj(7,60)],
  exemplo='Iguais ao 1: 3 (oposto), 5 (correspondente) e 7 (alterno externo).')
for it in a['itens']: it['fig']='a mesma figura'
a['itens'][0]['fig']=fig_par(60)
b=page('quantos ângulos têm cada medida','Responda com um número.',[
  item('Quantos dos 8 ângulos são agudos?',4,fig=fig_par(55)), item('Quantos são obtusos?',4,fig='a mesma figura'),
  item('Se t fosse perpendicular às paralelas, quantos seriam retos?',8,fig='a mesma figura'),
  item('Quantas medidas diferentes aparecem entre os 8 ângulos?',2,fig='a mesma figura')])
folha(69,U,9,'ver o quadro todo: os 8 ângulos têm só duas medidas.',a,b)

# 70
a=page('revisão da unidade','Revisão: responda no caderno.',[
  item('Correspondente do ângulo 3','7',fig=fig_par(75)), item('Alterno interno do ângulo 6','4',fig='a mesma figura'),
  item('Alterno externo do ângulo 2','8',fig='a mesma figura'), item('Colateral interno do ângulo 5','4',fig='a mesma figura'),
  item('Colateral externo do ângulo 7','2',fig='a mesma figura'), item('Tipo do par 1 e 7 (sigla)','AE',['alternos externos'],fig='a mesma figura'),
  item('Tipo do par 3 e 6 (sigla)','CI',['colaterais internos'],fig='a mesma figura'), item('1 e 8: iguais (C) ou somam 180° (S)?','S',['suplementares'],fig='a mesma figura'),
  item('4 e 6: iguais (C) ou somam 180° (S)?','C',['congruentes'],fig='a mesma figura'), item('Quantos ângulos são iguais ao ângulo 8 (sem contar o 8)?','3',fig='a mesma figura')])
b=page('revisão com medidas','O ângulo 7 mede 48°. Calcule os pedidos.',val_items(48,7,[1,2,4,6,8]))
folha(70,U,10,'revisão de toda a unidade (nada novo).',a,b)
