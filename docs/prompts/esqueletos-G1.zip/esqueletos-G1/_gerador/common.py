# Utilitários para escrever os esqueletos das folhas G1
from fractions import Fraction as Fr
import math, os, random

OUT='/home/claude/esq/out'
os.makedirs(OUT,exist_ok=True)

# ---------- graus, minutos e segundos ----------
def S(d=0,m=0,s=0): return Fr(d)*3600+Fr(m)*60+Fr(s)   # tudo em segundos
def deg(x): return Fr(x)*3600                            # graus (pode ser fração) -> segundos

def dms_parts(sec):
    sec=Fr(sec); assert sec>=0 and sec.denominator==1, f'não inteiro em segundos: {sec}'
    sec=int(sec); d,r=divmod(sec,3600); m,s=divmod(r,60); return d,m,s

def fmt(sec):
    """forma canônica + variantes aceitas"""
    d,m,s=dms_parts(sec)
    if m==0 and s==0: return str(d), [f'{d}°']
    if s==0:
        c=f"{d}°{m}'"; alt=[f"{d}°{m:02d}'", f"{d}°{m}'0\"", f"{d}°{m:02d}'00\""]
        if d==0: alt.append(f"{m}'")
        dec=Fr(d)+Fr(m,60)
        return c, list(dict.fromkeys([a for a in alt if a!=c]))
    c=f"{d}°{m}'{s}\""; alt=[f"{d}°{m:02d}'{s:02d}\""]
    if d==0: alt.append(f"{m}'{s}\"")
    return c, [a for a in dict.fromkeys(alt) if a!=c]

def fmt_txt(sec):  # para enunciados
    return fmt(sec)[0] if fmt(sec)[0].endswith(("'",'"')) else fmt(sec)[0]+'°'

def num(x):
    x=Fr(x)
    if x.denominator==1: return str(x.numerator)
    s=str(float(x)).replace('.',',')
    return s

# ---------- itens / páginas / folhas ----------
def item(enun, resp, aceitar=None, fig=None, alts=None, fonte=None, conjunto=False):
    return dict(enun=enun, resp=str(resp), aceitar=list(aceitar or []), fig=fig, alts=alts, fonte=fonte, conjunto=conjunto)

def ang_item(enun, sec, fig=None):
    c,alt=fmt(sec)
    if c.isdigit(): alt=[c+'°']+[a for a in alt if a!=c+'°']
    return item(enun,c,alt,fig)

def page(tarefa, instr, itens, exemplo=None, pontos=None):
    return dict(tarefa=tarefa, instr=instr, itens=itens, exemplo=exemplo, pontos=pontos)

def pontos_txt(n, override=None):
    if override: return override
    if 100%n==0: return f'{100//n} cada'
    base=100//n; extra=100-base*n
    return f'{base} cada (itens 1 a {extra}: {base+1})'

FOLHAS={}
def folha(n, unidade, pos, degrau, a, b):
    FOLHAS[n]=dict(n=n, unidade=unidade, pos=pos, degrau=degrau, a=a, b=b)

def valida(f):
    for lado in ('a','b'):
        p=f[lado]; n=len(p['itens'])
        assert 1<=n<=12, (f['n'],lado,'itens',n)
        assert len(p['instr'])<=60, (f['n'],lado,'instrução longa',len(p['instr']),p['instr'])
        for it in p['itens']:
            assert it['resp']!='', (f['n'],lado,it)
            low=it['enun'].lower()

def escreve(f):
    valida(f)
    L=[f"# G1 {f['n']} — {f['unidade']} {f['pos']}", f"Degrau novo: {f['degrau']}", ""]
    for lado,nome in (('a','Frente'),('b','Verso')):
        p=f[lado]
        L.append(f"## {nome} (G1 {f['n']}{lado})")
        L.append(f"Tarefa: {p['tarefa']}")
        L.append(f"Instrução: {p['instr']}")
        L.append(f"Pontos: {pontos_txt(len(p['itens']),p['pontos'])}")
        if p['exemplo']: L.append(f"Exemplo resolvido: {p['exemplo']}")
        L.append("Itens:")
        for i,it in enumerate(p['itens'],1):
            parts=[f"Enunciado: {it['enun']}"]
            if it['fig']: parts.append(f"Figura: {it['fig']}")
            if it['alts']: parts.append("Alternativas: "+' '.join(f'({k}) {v}' for k,v in zip('ABCDE',it['alts'])))
            r=it['resp']+(' (conjunto, qualquer ordem)' if it['conjunto'] else '')
            parts.append(f"Resposta: {r}")
            if it['aceitar']: parts.append("Aceitar também: "+'; '.join(it['aceitar']))
            if it['fonte']: parts.append(f"Fonte: {it['fonte']}")
            L.append(f"{i}. "+' | '.join(parts))
        L.append("")
    open(os.path.join(OUT,f"G1_{f['n']:03d}.md"),'w').write('\n'.join(L).rstrip()+'\n')

def classif(a):
    a=Fr(a)
    if a<90: return 'A'
    if a==90: return 'R'
    if a<180: return 'O'
    if a==180: return 'Ra'
    raise ValueError(a)
CLASSE_ACEITA={'A':['agudo'],'R':['reto'],'O':['obtuso'],'Ra':['raso','RA']}
def cls_item(enun, a, fig=None):
    c=classif(a); return item(enun,c,CLASSE_ACEITA[c],fig)
SN={'S':['Sim'],'N':['Não','Nao']}
def sn_item(enun,v): c='S' if v else 'N'; return item(enun,c,SN[c])
