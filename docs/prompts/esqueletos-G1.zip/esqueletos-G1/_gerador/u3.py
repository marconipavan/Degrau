from common import *
from u2 import disp
U='Complemento e suplemento'
def comp(x): return deg(90)-x
def sup(x): return deg(180)-x
D=deg
# 21
a=page('calcular o complemento','Calcule o complemento de cada ângulo.',
  [ang_item(f'Complemento de {v}°',comp(D(v))) for v in [20,35,45,10,72,89,1,64,50,18]],
  exemplo='Complemento de 30°: 90° − 30° = 60°.')
b=page('calcular o suplemento','Calcule o suplemento de cada ângulo.',
  [ang_item(f'Suplemento de {v}°',sup(D(v))) for v in [50,120,90,10,135,179,1,77,100,45]],
  exemplo='Suplemento de 50°: 180° − 50° = 130°.')
folha(21,U,1,'complemento (falta para 90°) e suplemento (falta para 180°).',a,b)

# 22
c22=[S(35,20),S(10,45),S(60,30),S(45,15),S(1,1),S(88,40),S(20,5),S(72,59),S(33,33),S(12,48)]
a=page('complemento com minutos','Calcule o complemento de cada ângulo.',
  [ang_item(f'Complemento de {disp(x)}',comp(x)) for x in c22],
  exemplo="Complemento de 35°20': 89°60' − 35°20' = 54°40'.")
s22=[S(100,15,0),S(45,30,30),S(120,0,40),S(10,10,10),S(179,59,59)]
b=page('suplemento com minutos e segundos','Calcule o suplemento de cada ângulo.',
  [ang_item(f'Suplemento de {disp(x)}',sup(x)) for x in s22],
  exemplo="Suplemento de 100°15': 179°60' − 100°15' = 79°45'.")
folha(22,U,2,'complemento e suplemento de ângulos com minutos e segundos.',a,b)

# 23
a=page('achar o ângulo a partir do complemento','Qual ângulo tem esse complemento?',
  [ang_item(f'O complemento mede {v}°',D(90-v)) for v in [25,60,45,10,89,30,72,5,54,1]],
  exemplo='O complemento mede 25°. O ângulo mede 90° − 25° = 65°.')
b=page('achar o ângulo a partir do suplemento','Qual ângulo tem esse suplemento?',
  [ang_item(f'O suplemento mede {v}°',D(180-v)) for v in [70,120,90,15,160,1,135,45,100,179]],
  exemplo='O suplemento mede 70°. O ângulo mede 180° − 70° = 110°.')
folha(23,U,3,'o caminho de volta: dado o complemento ou o suplemento, achar o ângulo.',a,b)

# 24
xs=[120,100,150,95,135,170,91,110,160,125]
a=page('complemento do suplemento','Calcule o complemento do suplemento.',
  [ang_item(f'Complemento do suplemento de {v}°',comp(sup(D(v)))) for v in xs],
  exemplo='Suplemento de 120° = 60°; complemento de 60° = 30°.')
ys=[30,10,45,80,1,60,25,72,89,15]
b=page('suplemento do complemento','Calcule o suplemento do complemento.',
  [ang_item(f'Suplemento do complemento de {v}°',sup(comp(D(v)))) for v in ys],
  exemplo='Complemento de 30° = 60°; suplemento de 60° = 120°.')
folha(24,U,4,'duas operações encadeadas, de dentro para fora.',a,b)

# 25
a=page('dobro, triplo e metade do complemento ou suplemento','Calcule.',[
  ang_item('O dobro do complemento de 30°',2*comp(D(30))),
  ang_item('A metade do suplemento de 40°',sup(D(40))/2),
  ang_item('O triplo do complemento de 70°',3*comp(D(70))),
  ang_item('A metade do complemento de 50°',comp(D(50))/2),
  ang_item('O dobro do suplemento de 150°',2*sup(D(150))),
  ang_item('A terça parte do suplemento de 30°',sup(D(30))/3),
  ang_item('O dobro do complemento de 45°',2*comp(D(45))),
  ang_item('A metade do suplemento de 75°',sup(D(75))/2),
  ang_item('O quádruplo do complemento de 80°',4*comp(D(80))),
  ang_item('A metade do complemento de 25°',comp(D(25))/2)],
  exemplo='O dobro do complemento de 30°: complemento = 60°; dobro = 120°.')
b=page('complemento ou suplemento do dobro e da metade','Calcule.',[
  ang_item('O complemento da metade de 100°',comp(D(100)/2)),
  ang_item('O suplemento do dobro de 35°',sup(2*D(35))),
  ang_item('O complemento do dobro de 20°',comp(2*D(20))),
  ang_item('O suplemento da metade de 150°',sup(D(150)/2)),
  ang_item('O complemento do triplo de 25°',comp(3*D(25)))],
  exemplo='O complemento da metade de 100°: metade = 50°; complemento = 40°.')
folha(25,U,5,'a ordem importa: "dobro do complemento" é diferente de "complemento do dobro".',a,b)

# 26
a=page('decidir se o complemento ou suplemento existe','Responda S (existe) ou N (não existe).',[
  sn_item('30° tem complemento?',True), sn_item('120° tem complemento?',False),
  sn_item('120° tem suplemento?',True), sn_item('89° tem complemento?',True),
  sn_item('179° tem suplemento?',True), sn_item('150° tem complemento?',False),
  sn_item('45° tem suplemento?',True), sn_item('95° tem complemento?',False),
  sn_item('60° tem suplemento?',True), sn_item('91° tem complemento?',False)],
  exemplo='120° tem complemento? Não: já passou de 90°.')
pares=[(35,55,'C'),(40,50,'C'),(120,60,'S'),(100,90,'N'),(45,135,'S'),(30,70,'N'),(89,1,'C'),(91,89,'S'),(60,60,'N'),(170,10,'S')]
ACE={'C':['complementares'],'S':['suplementares'],'N':['nenhum']}
for a1,a2,k in pares:
    assert (k=='C')==(a1+a2==90) and (k=='S')==(a1+a2==180)
b=page('classificar o par de ângulos','Par: complementares (C), suplementares (S) ou N?',
  [item(f'{a1}° e {a2}°',k,ACE[k]) for a1,a2,k in pares],
  exemplo='35° e 55° somam 90°: complementares (C).')
folha(26,U,6,'quando existe complemento e o que são ângulos complementares e suplementares.',a,b)

# 27
v27=[S(110,40),S(150,15),S(95,30),S(135,45),S(100,1)]
a=page('complemento do suplemento com minutos','Calcule o complemento do suplemento.',
  [ang_item(f'Complemento do suplemento de {disp(x)}',comp(sup(x))) for x in v27],
  exemplo="Suplemento de 110°40' = 69°20'; complemento = 20°40'.")
v27b=[S(25,10,30),S(45,0,15),S(10,20,30),S(60,59,59),S(1,1,1)]
b=page('suplemento do complemento com segundos','Calcule o suplemento do complemento.',
  [ang_item(f'Suplemento do complemento de {disp(x)}',sup(comp(x))) for x in v27b],
  exemplo="Complemento de 25°10'30\" = 64°49'30\"; suplemento = 115°10'30\".")
folha(27,U,7,'o encadeamento com minutos e segundos.',a,b)

# 28
a=page('suplemento menos complemento','Calcule: suplemento menos complemento.',
  [ang_item(f'Para o ângulo de {v}°',sup(D(v))-comp(D(v))) for v in [20,40,10,75,89,1,55,30,62,5]],
  exemplo='Para 20°: suplemento 160°, complemento 70°; 160° − 70° = 90°.')
b=page('usar a diferença de 90° entre suplemento e complemento','Calcule o que se pede.',[
  ang_item('O suplemento mede 130°. Quanto mede o complemento?',D(40)),
  ang_item('O complemento mede 25°. Quanto mede o suplemento?',D(115)),
  ang_item('O suplemento mede 100°. Quanto mede o complemento?',D(10)),
  ang_item("O complemento mede 33°20'. Quanto mede o suplemento?",S(123,20)),
  ang_item('O suplemento mede 179°. Quanto mede o complemento?',D(89))],
  exemplo='Suplemento 130° → complemento 130° − 90° = 40°.')
folha(28,U,8,'o bizu: o suplemento é sempre 90° maior que o complemento.',a,b)

# 29
a=page('expressões com complemento e suplemento','Calcule.',[
  ang_item('O complemento do triplo de 20°',comp(3*D(20))),
  ang_item('O triplo do complemento de 20°',3*comp(D(20))),
  ang_item('A metade do suplemento do complemento de 40°',sup(comp(D(40)))/2),
  ang_item('O suplemento da metade do complemento de 30°',sup(comp(D(30))/2)),
  ang_item('O complemento do suplemento do dobro de 50°',comp(sup(2*D(50)))),
  ang_item('O dobro do complemento do suplemento de 140°',2*comp(sup(D(140)))),
  ang_item('O suplemento do dobro do complemento de 70°',sup(2*comp(D(70)))),
  ang_item('A metade do complemento de 31°',comp(D(31))/2),
  ang_item('O complemento da terça parte de 120°',comp(D(120)/3)),
  ang_item('A terça parte do suplemento do complemento de 15°',sup(comp(D(15)))/3)])
b=page('expressões com minutos','Calcule.',[
  ang_item("O dobro do complemento de 40°30'",2*comp(S(40,30))),
  ang_item("A metade do suplemento de 100°10'",sup(S(100,10))/2),
  ang_item("O complemento da metade de 50°20'",comp(S(50,20)/2)),
  ang_item("O suplemento do triplo de 20°15'",sup(3*S(20,15))),
  ang_item("A metade do complemento de 45°",comp(D(45))/2)])
folha(29,U,9,'expressões com três operações encadeadas.',a,b)

# 30
a=page('revisão da unidade','Revisão: responda no caderno.',[
  ang_item('Complemento de 37°',comp(D(37))), ang_item('Suplemento de 112°',sup(D(112))),
  ang_item("Complemento de 51°45'",comp(S(51,45))), ang_item('O suplemento mede 64°. Qual é o ângulo?',D(116)),
  ang_item('Complemento do suplemento de 165°',comp(sup(D(165)))), ang_item('O dobro do complemento de 65°',2*comp(D(65))),
  sn_item('100° tem complemento?',False), item('35° e 145° são: C, S ou N?','S',['suplementares']),
  ang_item('O suplemento mede 150°. Quanto mede o complemento?',D(60)), ang_item('O complemento da metade de 70°',comp(D(35)))])
b=page('revisão com minutos e segundos','Revisão: responda no caderno.',[
  ang_item("Suplemento de 120°20'30\"",sup(S(120,20,30))),
  ang_item("Suplemento do complemento de 12°40'",sup(comp(S(12,40)))),
  ang_item("A metade do suplemento de 85°",sup(D(85))/2),
  ang_item("O complemento mede 44°59'. Qual é o ângulo?",comp(S(44,59))),
  ang_item("Suplemento menos complemento de 17°17'",D(90))])
folha(30,U,10,'revisão de toda a unidade (nada novo).',a,b)
