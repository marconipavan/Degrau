from common import *
U='Equações com ângulos'
def solve(f):
    """f(x)=0, linear em x (graus, Fraction). Devolve x em graus."""
    f0=Fr(f(Fr(0))); f1=Fr(f(Fr(1))); a=f1-f0; assert a!=0; return -f0/a
def x_item(enun,f,cond=lambda x:True,ask=None):
    x=solve(f); assert cond(x), (enun,x)
    v = x if ask is None else ask(x)
    return ang_item(enun, deg(v))
C=lambda x:90-x; Sp=lambda x:180-x
okc=lambda x:0<x<90; oks=lambda x:0<x<180

# 31
eqs=[('x + 35° = 90°',lambda x:x+35-90),('x + 110° = 180°',lambda x:x+110-180),('2x = 90°',lambda x:2*x-90),
     ('3x = 180°',lambda x:3*x-180),('x + x = 90°',lambda x:2*x-90),('2x + 10° = 90°',lambda x:2*x+10-90),
     ('3x − 30° = 180°',lambda x:3*x-30-180),('4x + 20° = 180°',lambda x:4*x+20-180),('5x = 90°',lambda x:5*x-90),('x/2 = 35°',lambda x:x/2-35)]
a=page('resolver equações com ângulos','Resolva: quanto vale x?',[x_item(e,f) for e,f in eqs],
  exemplo='2x + 10° = 90° → 2x = 80° → x = 40°.')
b=page('complementares em função de x','Os dois ângulos são complementares. Ache x.',[
  x_item('x e 2x',lambda x:x+2*x-90,okc), x_item('x e 4x',lambda x:5*x-90,okc),
  x_item('x e x + 20°',lambda x:2*x+20-90,okc), x_item('2x e 3x',lambda x:5*x-90,okc),
  x_item('x + 10° e 2x + 20°',lambda x:3*x+30-90,okc)],
  exemplo='x e 2x complementares: x + 2x = 90° → x = 30°.')
folha(31,U,1,'equações simples; ângulos complementares escritos com x.',a,b)

# 32
a=page('suplementares em função de x','Os dois ângulos são suplementares. Ache x.',[
  x_item('x e 2x',lambda x:3*x-180,oks), x_item('x e 5x',lambda x:6*x-180,oks),
  x_item('x e x + 40°',lambda x:2*x+40-180,oks), x_item('2x e 3x + 30°',lambda x:5*x+30-180,oks),
  x_item('x − 10° e x + 30°',lambda x:2*x+20-180,oks)],
  exemplo='x e 2x suplementares: x + 2x = 180° → x = 60°.')
b=page('achar o ângulo, não só o x','Ache x e responda o que se pede.',[
  x_item('Suplementares x e 3x. Quanto mede o maior?',lambda x:4*x-180,oks,ask=lambda x:3*x),
  x_item('Complementares x e 2x. Quanto mede o maior?',lambda x:3*x-90,okc,ask=lambda x:2*x),
  x_item('Suplementares x e x + 20°. Quanto mede o maior?',lambda x:2*x+20-180,oks,ask=lambda x:x+20),
  x_item('Complementares 2x e 3x. Quanto mede o menor?',lambda x:5*x-90,okc,ask=lambda x:2*x),
  x_item('Suplementares x + 15° e 2x. Quanto mede o menor?',lambda x:3*x+15-180,oks,ask=lambda x:min(x+15,2*x))],
  exemplo='Suplementares x e 3x: x = 45°; o maior mede 3 × 45° = 135°.')
folha(32,U,2,'suplementares com x, e depois usar o x para achar o ângulo.',a,b)

# 33
a=page('o complemento comparado com o próprio ângulo','Ache o ângulo x.',[
  x_item('O complemento de x é igual a x.',lambda x:C(x)-x,okc),
  x_item('O complemento de x é o dobro de x.',lambda x:C(x)-2*x,okc),
  x_item('O complemento de x é a metade de x.',lambda x:C(x)-x/2,okc),
  x_item('O complemento de x é 20° a mais que x.',lambda x:C(x)-(x+20),okc),
  x_item('O complemento de x é o quádruplo de x.',lambda x:C(x)-4*x,okc)],
  exemplo='Complemento de x igual ao dobro de x: 90° − x = 2x → x = 30°.')
b=page('o suplemento comparado com o próprio ângulo','Ache o ângulo x.',[
  x_item('O suplemento de x é igual a x.',lambda x:Sp(x)-x,oks),
  x_item('O suplemento de x é o triplo de x.',lambda x:Sp(x)-3*x,oks),
  x_item('O suplemento de x é igual a 5x.',lambda x:Sp(x)-5*x,oks),
  x_item('O suplemento de x excede x em 40°.',lambda x:Sp(x)-(x+40),oks),
  x_item('O suplemento de x é a metade de x.',lambda x:Sp(x)-x/2,oks)],
  exemplo='Suplemento de x igual ao triplo de x: 180° − x = 3x → x = 45°.')
folha(33,U,3,'a frase vira equação: "o complemento de x" vira 90° − x.',a,b)

# 34
a=page('suplemento como múltiplo do complemento','Ache o ângulo x.',[
  x_item('O suplemento de x é o triplo do complemento de x.',lambda x:Sp(x)-3*C(x),okc),
  x_item('O suplemento de x é o quádruplo do complemento de x.',lambda x:Sp(x)-4*C(x),okc),
  x_item('O suplemento de x é o quíntuplo do complemento de x.',lambda x:Sp(x)-5*C(x),okc),
  x_item('O suplemento de x é 6 vezes o complemento de x.',lambda x:Sp(x)-6*C(x),okc),
  x_item('O suplemento de x é 10 vezes o complemento de x.',lambda x:Sp(x)-10*C(x),okc)],
  exemplo='180° − x = 3(90° − x) → 180° − x = 270° − 3x → 2x = 90° → x = 45°.')
b=page('complemento como fração do suplemento','Ache o ângulo x.',[
  x_item('O complemento de x é a terça parte do suplemento de x.',lambda x:C(x)-Sp(x)/3,okc),
  x_item('O complemento de x é a quarta parte do suplemento de x.',lambda x:C(x)-Sp(x)/4,okc),
  x_item('O complemento de x é a quinta parte do suplemento de x.',lambda x:C(x)-Sp(x)/5,okc),
  x_item('O complemento de x é 2/7 do suplemento de x.',lambda x:C(x)-Fr(2,7)*Sp(x),okc),
  x_item('O complemento de x é 3/8 do suplemento de x.',lambda x:C(x)-Fr(3,8)*Sp(x),okc)],
  exemplo='90° − x = (180° − x)/3 → 270° − 3x = 180° − x → x = 45°.')
folha(34,U,4,'o clássico: complemento e suplemento do mesmo x na mesma equação.',a,b)

# 35
a=page('soma ou diferença de complemento e suplemento','Ache o ângulo x.',[
  x_item('A soma do complemento com o suplemento de x é 150°.',lambda x:C(x)+Sp(x)-150,okc),
  x_item('A soma do complemento com o suplemento de x é 200°.',lambda x:C(x)+Sp(x)-200,okc),
  x_item('x mais o dobro do seu complemento dá 140°.',lambda x:x+2*C(x)-140,okc),
  x_item('x mais o seu suplemento mais o seu complemento dá 210°.',lambda x:x+Sp(x)+C(x)-210,okc),
  x_item('O suplemento de x menos o dobro de x dá 30°.',lambda x:Sp(x)-2*x-30,oks)])
b=page('somas com metade e dobro','Ache o ângulo x.',[
  x_item('A metade do suplemento de x mais o complemento de x dá 105°.',lambda x:Sp(x)/2+C(x)-105,okc),
  x_item('O dobro do complemento de x mais a metade de x dá 120°.',lambda x:2*C(x)+x/2-120,okc),
  x_item('A metade do complemento de x é igual à quarta parte de x.',lambda x:C(x)/2-x/4,okc),
  x_item('O triplo do complemento de x menos o suplemento de x dá 20°.',lambda x:3*C(x)-Sp(x)-20,okc),
  x_item('A terça parte do suplemento de x é igual ao complemento de x mais 10°.',lambda x:Sp(x)/3-C(x)-10,okc)])
folha(35,U,5,'somas e diferenças: o x aparece em mais de um termo.',a,b)

# 36
a=page('resolver e responder outro ângulo','Ache x e responda o que se pede.',[
  x_item('O suplemento de x é o triplo de x. Quanto mede o complemento de x?',lambda x:Sp(x)-3*x,okc,ask=C),
  x_item('O complemento de x é o dobro de x. Quanto mede o suplemento de x?',lambda x:C(x)-2*x,okc,ask=Sp),
  x_item('O suplemento de x é o quádruplo do complemento. Quanto mede o suplemento?',lambda x:Sp(x)-4*C(x),okc,ask=Sp),
  x_item('O complemento de x é a quarta parte do suplemento. Quanto mede o complemento?',lambda x:C(x)-Sp(x)/4,okc,ask=C),
  x_item('O suplemento de x é igual a 5x. Quanto mede o dobro de x?',lambda x:Sp(x)-5*x,oks,ask=lambda x:2*x)])
b=page('respostas em graus e minutos','Ache o ângulo x (pode dar minutos).',[
  x_item('O complemento de x é o quíntuplo de x.',lambda x:C(x)-5*x,okc),
  x_item('O suplemento de x é o quíntuplo do complemento de x.',lambda x:Sp(x)-5*C(x),okc),
  x_item('O suplemento de x é igual a 7x.',lambda x:Sp(x)-7*x,oks),
  x_item('O complemento de x é 7 vezes x.',lambda x:C(x)-7*x,okc),
  x_item('O complemento de x é 1/5 do suplemento de x.',lambda x:C(x)-Sp(x)/5,okc)],
  exemplo="Complemento de x é o triplo de x: 90° − x = 3x → x = 22,5° = 22°30'.")
folha(36,U,6,'resposta que não é o x, e x que não dá inteiro (vira graus e minutos).',a,b)

# 37
a=page('dois ângulos com soma conhecida','Ache o que se pede.',[
  x_item('Complementares; um é o dobro do outro mais 15°. O maior?',lambda x:x+2*x+15-90,okc,ask=lambda x:2*x+15),
  x_item('Suplementares; um é o triplo do outro menos 20°. O maior?',lambda x:x+3*x-20-180,oks,ask=lambda x:3*x-20),
  x_item('Complementares; um excede o outro em 30°. O menor?',lambda x:x+x+30-90,okc),
  x_item('Suplementares; um excede o outro em 40°. O menor?',lambda x:2*x+40-180,oks),
  x_item('Complementares; um é a metade do outro. O menor?',lambda x:x+2*x-90,okc)],
  exemplo='Complementares, um excede o outro em 30°: x + (x + 30°) = 90° → x = 30°.')
b=page('dois ângulos com diferença conhecida','Ache o que se pede.',[
  x_item('Suplementares que diferem em 50°. O maior?',lambda x:2*x+50-180,oks,ask=lambda x:x+50),
  x_item('Complementares que diferem em 10°. O maior?',lambda x:2*x+10-90,okc,ask=lambda x:x+10),
  x_item('Suplementares que diferem em 100°. O menor?',lambda x:2*x+100-180,oks),
  x_item('Complementares que diferem em 45°. O menor?',lambda x:2*x+45-90,okc),
  x_item('Suplementares que diferem em 15°. O menor?',lambda x:2*x+15-180,oks)])
folha(37,U,7,'dois ângulos desconhecidos: um escrito em função do outro.',a,b)

# 38
def razao(p,q,total,qual):
    k=Fr(total,p+q); return deg(k*(p if qual=='menor' else q))
a=page('ângulos em razão dada','Ache o ângulo pedido.',[
  ang_item('Complementares na razão 2 : 3. O menor?',razao(2,3,90,'menor')),
  ang_item('Suplementares na razão 4 : 5. O maior?',razao(4,5,180,'maior')),
  ang_item('Suplementares na razão 1 : 5. O menor?',razao(1,5,180,'menor')),
  ang_item('Complementares na razão 1 : 2. O maior?',razao(1,2,90,'maior')),
  ang_item('Complementares na razão 7 : 8. O menor?',razao(7,8,90,'menor'))],
  exemplo='Complementares na razão 2 : 3: 2k + 3k = 90° → k = 18°; o menor mede 36°.')
b=page('razão com resposta em graus e minutos','Ache o ângulo pedido.',[
  ang_item('Complementares na razão 3 : 5. O menor?',razao(3,5,90,'menor')),
  ang_item('Suplementares na razão 3 : 5. O maior?',razao(3,5,180,'maior')),
  ang_item('Complementares na razão 1 : 3. O menor?',razao(1,3,90,'menor')),
  ang_item('Suplementares na razão 5 : 7. O menor?',razao(5,7,180,'menor')),
  ang_item('Suplementares na razão 1 : 7. O menor?',razao(1,7,180,'menor'))])
folha(38,U,8,'razão entre os dois ângulos (partes iguais de tamanho k).',a,b)

# 39
a=page('equações com encadeamento','Ache o ângulo x.',[
  x_item('O suplemento do complemento de x é 7 vezes x.',lambda x:Sp(C(x))-7*x,okc),
  x_item('O complemento do suplemento de x é a terça parte de x.',lambda x:C(Sp(x))-x/3,lambda x:90<x<180),
  x_item('O suplemento do complemento de x é o triplo de x.',lambda x:Sp(C(x))-3*x,okc),
  x_item('O complemento do suplemento de x é a quarta parte de x.',lambda x:C(Sp(x))-x/4,lambda x:90<x<180),
  x_item('O suplemento do complemento de x é igual ao suplemento de x.',lambda x:Sp(C(x))-Sp(x),okc)],
  exemplo='Suplemento do complemento de x = 90° + x. Então 90° + x = 7x → x = 15°.')
b=page('mistura de tipos de equação','Ache o ângulo pedido.',[
  x_item('O suplemento de x é o triplo do complemento de x. Ache x.',lambda x:Sp(x)-3*C(x),okc),
  ang_item('Complementares na razão 4 : 5. O maior?',razao(4,5,90,'maior')),
  x_item('Suplementares x + 30° e 2x. Ache x.',lambda x:3*x+30-180,oks),
  x_item('O complemento de x é igual a x/2 + 15°. Ache x.',lambda x:C(x)-(x/2+15),okc),
  x_item('O suplemento do complemento de x é 5 vezes x. Ache x.',lambda x:Sp(C(x))-5*x,okc)])
folha(39,U,9,'equações em que um termo já é encadeado (suplemento do complemento).',a,b)

# 40
a=page('revisão da unidade','Revisão: ache o que se pede.',[
  x_item('3x − 15° = 90°. Ache x.',lambda x:3*x-15-90),
  x_item('Complementares x e 5x. Ache x.',lambda x:6*x-90,okc),
  x_item('Suplementares 2x e x + 30°. Ache x.',lambda x:3*x+30-180,oks),
  x_item('O complemento de x é o dobro de x. Ache x.',lambda x:C(x)-2*x,okc),
  x_item('O suplemento de x é o triplo do complemento. Ache x.',lambda x:Sp(x)-3*C(x),okc),
  x_item('Complementares que diferem em 20°. O maior?',lambda x:2*x+20-90,okc,ask=lambda x:x+20),
  ang_item('Suplementares na razão 2 : 7. O menor?',razao(2,7,180,'menor')),
  x_item('O complemento de x é a metade do suplemento menos 15°. Ache x.',lambda x:C(x)-(Sp(x)/2-15),okc),
  x_item('O suplemento do complemento de x é 4 vezes x. Ache x.',lambda x:Sp(C(x))-4*x,okc),
  x_item('O suplemento de x é igual a 3x. Quanto mede o complemento?',lambda x:Sp(x)-3*x,okc,ask=C)])
b=page('revisão com respostas em graus e minutos','Revisão: ache o que se pede.',[
  x_item('O complemento de x é o triplo de x. Ache x.',lambda x:C(x)-3*x,okc),
  x_item('O suplemento de x é 7 vezes x. Ache x.',lambda x:Sp(x)-7*x,oks),
  ang_item('Complementares na razão 3 : 5. O maior?',razao(3,5,90,'maior')),
  x_item('O suplemento de x é o quíntuplo do complemento. Ache x.',lambda x:Sp(x)-5*C(x),okc),
  x_item('Complementares que diferem em 25°. O menor?',lambda x:2*x+25-90,okc)])
folha(40,U,10,'revisão de toda a unidade (nada novo).',a,b)
