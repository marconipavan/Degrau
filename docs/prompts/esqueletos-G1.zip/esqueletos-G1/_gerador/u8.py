from common import *
from u5 import ev
from u4 import solve
from u7 import fig_par, valor, tipo
U='Paralelas: calcular'
def pq(d_hint, escr, ask='x', enun=None):
    """escr: {pos: texto}. Calcula x e a direção d da transversal a partir das expressões; confere tudo."""
    ent=[(p,e) for p,e in escr.items() if e!='y']
    def f(p,e,x):
        v = ev(e,x) if 'x' in e else Fr(e.replace('°',''))
        return v if p%2==1 else 180-v
    (p1,e1),(p2,e2)=ent[0],ent[1]
    if 'x' in e1 or 'x' in e2:
        x=solve(lambda x:f(p1,e1,x)-f(p2,e2,x))
    else: x=None
    d=f(p1,e1,x)
    assert 0<d<180 and d!=90 and d.denominator<=2, (escr,x,d)
    for p,e in ent:
        assert f(p,e,x)==d, (escr,p,e,x,d)
        v = ev(e,x) if 'x' in e else None
        if v is not None: assert v>0
    if ask=='x': resp=x
    elif ask=='y':
        yp=[p for p,e in escr.items() if e=='y'][0]; resp=Fr(valor(yp,d))
    else: resp=Fr(valor(ask,d))
    q={'x':'Ache x.','y':'Ache y.'}.get(ask, f'Quanto mede o ângulo na posição {ask}?') if enun is None else enun
    dd=int(d) if d.denominator==1 else float(d)
    return ang_item(q, deg(resp), fig=fig_par(str(dd).replace('.',','),escr))
def lab(n): # texto de posição para enunciado
    from u7 import POS
    return f'em {POS[n][0]}, {POS[n][1]}'

# 71
a=page('correspondentes: expressão igual ao valor','Ângulos correspondentes. Ache x.',[
  pq(70,{1:'70°',5:'2x + 10°'}), pq(110,{2:'70°',6:'3x − 20°'}), pq(50,{3:'50°',7:'x + 15°'}),
  pq(125,{8:'55°',4:'5x + 5°'}), pq(80,{5:'80°',1:'4x'})],
  exemplo='Correspondentes são iguais: 2x + 10° = 70° → x = 30°.')
b=page('alternos internos: expressão igual ao valor','Ângulos alternos internos. Ache x.',[
  pq(60,{3:'60°',5:'2x'}), pq(65,{4:'115°',6:'x + 75°'}), pq(120,{5:'120°',3:'3x + 30°'}),
  pq(75,{6:'105°',4:'5x − 20°'}), pq(40,{3:'40°',5:'x/2 + 15°'})],
  exemplo='Alternos internos são iguais: 2x = 60° → x = 30°.')
folha(71,U,1,'a relação vira equação: ângulos iguais, uma expressão e um valor.',a,b)

# 72
a=page('correspondentes: duas expressões','Correspondentes. Ache x.',[
  pq(80,{1:'3x − 10°',5:'2x + 20°'}), pq(130,{2:'x + 35°',6:'2x + 10°'}), pq(70,{3:'4x + 10°',7:'5x − 5°'}),
  pq(120,{4:'2x + 30°',8:'3x + 15°'}), pq(45,{5:'x + 25°',1:'3x − 15°'})],
  exemplo='3x − 10° = 2x + 20° → x = 30°.')
b=page('alternos internos: duas expressões','Alternos internos. Ache x.',[
  pq(70,{3:'2x + 10°',5:'3x − 20°'}), pq(50,{4:'5x + 5°',6:'4x + 30°'}), pq(110,{5:'x + 50°',3:'2x − 10°'}),
  pq(60,{6:'3x',4:'x + 80°'}), pq(84,{3:'4x − 10°',5:'2x + 30°'})],
  exemplo='2x + 10° = 3x − 20° → x = 30°.')
folha(72,U,2,'expressão dos dois lados da equação.',a,b)

# 73
a=page('colaterais internos: somam 180°','Colaterais internos. Ache x.',[
  pq(70,{4:'110°',5:'x + 30°'}), pq(60,{3:'60°',6:'2x'}), pq(130,{5:'130°',4:'3x + 5°'}),
  pq(45,{6:'135°',3:'x + 20°'}), pq(100,{4:'80°',5:'4x − 20°'})],
  exemplo='Colaterais internos somam 180°: 110° + x + 30° = 180° → x = 40°.')
b=page('colaterais internos: duas expressões','Colaterais internos. Ache x.',[
  pq(70,{4:'3x + 50°',5:'2x + 30°'}), pq(80,{3:'x + 50°',6:'2x + 40°'}), pq(120,{5:'4x',4:'x + 30°'}),
  pq(50,{6:'5x − 20°',3:'2x + 11°'}), pq(65,{4:'3x + 25°',5:'x + 45°'})],
  exemplo='3x + 50° + 2x + 30° = 180° → 5x = 100° → x = 20°.')
folha(73,U,3,'colaterais: a equação agora é soma igual a 180°.',a,b)

# 74
a=page('achar a medida do ângulo (iguais)','Ache x e depois a medida pedida.',[
  pq(80,{1:'3x − 10°',5:'2x + 20°'},ask=1,enun='Correspondentes. Quanto mede o ângulo 3x − 10°?'),
  pq(70,{3:'2x + 10°',5:'3x − 20°'},ask=3,enun='Alternos internos. Quanto mede cada um?'),
  pq(130,{2:'x + 35°',6:'2x + 10°'},ask=1,enun='Correspondentes. Quanto mede o ângulo 1 (em r, acima à direita)?'),
  pq(60,{6:'3x',4:'x + 80°'},ask=5,enun='Alternos internos. Quanto mede o ângulo em s, acima à direita?'),
  pq(84,{3:'4x − 10°',5:'2x + 30°'},ask=4,enun='Alternos internos. Quanto mede o ângulo em r, abaixo à direita?')])
b=page('achar a medida do ângulo (colaterais)','Ache x e depois a medida pedida.',[
  pq(70,{4:'3x + 50°',5:'2x + 30°'},ask=4,enun='Colaterais internos. Quanto mede o ângulo 3x + 50°?'),
  pq(80,{3:'x + 50°',6:'2x + 40°'},ask=6,enun='Colaterais internos. Quanto mede o ângulo 2x + 40°?'),
  pq(120,{5:'4x',4:'x + 30°'},ask=5,enun='Colaterais internos. Quanto mede o ângulo 4x?'),
  pq(50,{6:'5x − 20°',3:'2x + 11°'},ask=2,enun='Colaterais internos. Quanto mede o ângulo em r, acima à esquerda?'),
  pq(65,{4:'3x + 25°',5:'x + 45°'},ask=1,enun='Colaterais internos. Quanto mede o ângulo em r, acima à direita?')])
folha(74,U,4,'a resposta é o ângulo, não o x: substituir x de volta.',a,b)

# 75
a=page('alternos externos','Alternos externos. Ache x.',[
  pq(75,{1:'2x + 15°',7:'3x'}), pq(115,{2:'x + 40°',8:'2x + 10°'}), pq(55,{7:'4x − 5°',1:'x + 40°'}),
  pq(140,{8:'2x',2:'x + 20°'}), pq(66,{1:'3x − 12°',7:'2x + 14°'})],
  exemplo='Alternos externos são iguais: 2x + 15° = 3x → x = 15°.')
b=page('colaterais externos','Colaterais externos. Ache x.',[
  pq(70,{1:'x + 40°',8:'3x + 20°'}), pq(120,{2:'2x',7:'x + 90°'}), pq(50,{7:'5x',2:'6x + 15°'}),
  pq(100,{8:'x + 50°',1:'4x − 20°'}), pq(35,{1:'x + 15°',8:'2x + 30°'})],
  exemplo='Colaterais externos somam 180°: x + 40° + 3x + 20° = 180° → x = 30°.')
folha(75,U,5,'as mesmas contas para os pares externos.',a,b)

# 76
a=page('duas incógnitas: x e y','Ache o valor pedido.',[
  pq(80,{1:'2x + 10°',5:'80°',6:'y'},ask='x'), pq(80,{1:'2x + 10°',5:'80°',6:'y'},ask='y'),
  pq(55,{3:'x + 15°',5:'55°',8:'y'},ask='x'), pq(55,{3:'x + 15°',5:'55°',8:'y'},ask='y')],
  exemplo='Ache primeiro o x com um par; depois o y com outro par (lado a lado soma 180°).')
b=page('duas incógnitas, duas expressões','Ache o valor pedido.',[
  pq(70,{1:'3x + 10°',5:'2x + 30°',2:'y'},ask='x'), pq(70,{1:'3x + 10°',5:'2x + 30°',2:'y'},ask='y'),
  pq(115,{4:'x + 50°',6:'2x − 15°',7:'y'},ask='x'), pq(115,{4:'x + 50°',6:'2x − 15°',7:'y'},ask='y')])
folha(76,U,6,'duas incógnitas na mesma figura.',a,b)

# 77
a=page('expressões com metade e terça parte','Ache x.',[
  pq(60,{1:'x/2 + 20°',5:'60°'}), pq(50,{3:'x/2 + 10°',5:'x − 30°'}), pq(70,{4:'x/3 + 90°',5:'70°'}),
  pq(80,{2:'x/2 + 60°',6:'x + 20°'}), pq(40,{6:'x + 80°',3:'x/2 + 10°'})])
b=page('x que não dá inteiro','Ache x (pode dar graus e minutos).',[
  pq(75,{1:'2x',5:'75°'}), pq(100,{3:'4x',7:'100°'}), pq(50,{4:'2x + 15°',5:'50°'}),
  pq(65,{5:'4x + 5°',3:'65°'}), pq(110,{8:'2x − 5°',1:'110°'})],
  exemplo="2x = 75° → x = 37,5° = 37°30'.")
folha(77,U,7,'expressões com frações de x e respostas em graus e minutos.',a,b)

# 78
a=page('identificar a relação e resolver','Ache x (descubra se são iguais ou somam 180°).',[
  pq(72,{1:'2x + 12°',7:'3x − 18°'}), pq(72,{4:'x + 18°',5:'2x − 12°'}), pq(72,{2:'3x',6:'2x + 36°'}),
  pq(72,{3:'x + 32°',6:'3x − 12°'}), pq(72,{1:'4x − 8°',8:'2x + 20°'})])
b=page('identificar a relação e achar o ângulo','Ache a medida pedida.',[
  pq(58,{2:'3x + 2°',8:'2x + 42°'},ask=2,enun='Quanto mede o ângulo 3x + 2°?'),
  pq(58,{3:'x + 18°',6:'3x + 2°'},ask=6,enun='Quanto mede o ângulo 3x + 2°?'),
  pq(58,{1:'2x',5:'x + 29°'},ask=4,enun='Quanto mede o ângulo em r, abaixo à direita?'),
  pq(58,{4:'4x − 2°',6:'3x + 28°'},ask=7,enun='Quanto mede o ângulo em s, abaixo à esquerda?'),
  pq(58,{7:'x + 8°',2:'3x − 28°'},ask=1,enun='Quanto mede o ângulo em r, acima à direita?')])
folha(78,U,8,'nenhum nome é dado: o aluno decide se os ângulos são iguais ou somam 180°.',a,b)

# 79
a=page('ângulos sem nome de par (passar por um terceiro)','Ache x.',[
  pq(92,{1:'2x + 20°',6:'3x + 10°'}), pq(60,{2:'x + 75°',7:'2x'}), pq(110,{4:'3x − 20°',5:'x + 80°'}),
  pq(48,{3:'x + 18°',8:'4x − 48°'}), pq(135,{2:'x',5:'3x − 40°'})],
  exemplo='1 e 6 não têm nome, mas 1 = 5 (correspondentes) e 5 + 6 = 180°. Então 1 + 6 = 180°.')
b=page('ângulos sem nome de par: achar a medida','Ache a medida pedida.',[
  pq(92,{1:'2x + 20°',6:'3x + 10°'},ask=8,enun='Quanto mede o ângulo em s, abaixo à direita?'),
  pq(60,{2:'x + 75°',7:'2x'},ask=4,enun='Quanto mede o ângulo em r, abaixo à direita?'),
  pq(110,{4:'3x − 20°',5:'x + 80°'},ask=7,enun='Quanto mede o ângulo em s, abaixo à esquerda?'),
  pq(48,{3:'x + 18°',8:'4x − 48°'},ask=2,enun='Quanto mede o ângulo em r, acima à esquerda?'),
  pq(135,{2:'x',5:'3x − 40°'},ask=6,enun='Quanto mede o ângulo em s, acima à esquerda?')])
folha(79,U,9,'pares sem nome: chegar à relação passando por um terceiro ângulo.',a,b)

# 80
a=page('revisão da unidade','Revisão: ache x.',[
  pq(76,{1:'2x + 16°',5:'76°'}), pq(76,{3:'3x − 14°',5:'2x + 16°'}), pq(76,{4:'x + 74°',5:'2x + 22°'}),
  pq(76,{1:'4x',7:'3x + 19°'}), pq(76,{2:'x + 74°',7:'x + 46°'})])
b=page('revisão com medida e com par sem nome','Revisão: ache a medida pedida.',[
  pq(104,{1:'2x + 24°',5:'3x − 16°'},ask=1,enun='Quanto mede o ângulo 2x + 24°?'),
  pq(104,{4:'x + 36°',6:'2x − 32°'},ask=4,enun='Quanto mede o ângulo x + 36°?'),
  pq(104,{1:'3x − 46°',6:'2x − 24°'},ask=8,enun='Quanto mede o ângulo em s, abaixo à direita?'),
  pq(104,{2:'x/2 + 38°',8:'x + 26°'},ask='x'),
  pq(104,{3:'2x',5:'104°',6:'y'},ask='y')])
folha(80,U,10,'revisão de toda a unidade (nada novo).',a,b)
