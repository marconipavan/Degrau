from common import *
from u2 import disp
from u4 import solve
from u5 import nm, bis_item, cruz_eq, linha_item, bis2_item, raios_fig, cruz_fig
U='Revisão 1'
C=lambda x:deg(90)-x; Sp=lambda x:deg(180)-x; D=deg
R='Revisão: responda no caderno.'
def xi(enun,f,ask=None):
    x=solve(f); return ang_item(enun, deg(x if ask is None else ask(x)))

# 51: unidades 1 e 2
a=page('revisão: reconhecer ângulos',R,[
  item(f'Vértice de {nm("K","L","M")}','L'), cls_item('Classifique 91°',91), cls_item('Classifique 2/3 de um reto',60),
  ang_item('1/5 de volta',D(72)), ang_item('Menor ângulo dos ponteiros às 5 h',D(150)), cls_item('Classifique o menor ângulo às 3 h',90),
  item('Quantos ângulos formam 3 semirretas de mesma origem?',3), item('E 6 semirretas?',15),
  ang_item('Menor obtuso inteiro',D(91)), sn_item('Dois agudos podem somar 90°?',True)])
b=page('revisão: graus, minutos e segundos',R,[
  item("Quantos minutos em 4°30'?",'270',["270'"]), ang_item("150'",S(0,150)), ang_item("18°47' + 21°13'",S(18,47)+S(21,13)),
  ang_item("90° − 47°38'",D(90)-S(47,38)), ang_item("3 × 15°25'",3*S(15,25)), ang_item("45° ÷ 4",D(45)/4),
  ang_item('12,5°',D(Fr(25,2))), ang_item("10°10'10\" + 9°49'50\"",S(10,10,10)+S(9,49,50)),
  ang_item("180° − 99°59'59\"",D(180)-S(99,59,59)), ang_item("100°20' ÷ 2",S(100,20)/2)])
folha(51,U,1,'mistura das unidades 1 e 2 (reconhecer; graus, minutos e segundos).',a,b)

# 52: unidades 2 e 3
a=page('revisão: complemento e suplemento',R,[
  ang_item('Complemento de 58°',C(D(58))), ang_item('Suplemento de 58°',Sp(D(58))), ang_item("Complemento de 22°35'",C(S(22,35))),
  ang_item("Suplemento de 147°12'",Sp(S(147,12))), ang_item('O complemento mede 17°. O ângulo?',D(73)),
  ang_item('Complemento do suplemento de 138°',C(Sp(D(138)))), ang_item('Suplemento do complemento de 38°',Sp(C(D(38)))),
  ang_item('O triplo do complemento de 64°',3*C(D(64))), ang_item('O suplemento mede 112°. O complemento?',D(22)),
  item('25° e 155° são: C, S ou N?','S',['suplementares'])])
b=page('revisão: complemento e suplemento com segundos',R,[
  ang_item("Complemento de 30°0'45\"",C(S(30,0,45))), ang_item("Suplemento de 79°59'1\"",Sp(S(79,59,1))),
  ang_item("A metade do complemento de 41°",C(D(41))/2), ang_item("Complemento do suplemento de 140°30'",C(Sp(S(140,30)))),
  ang_item("Suplemento do dobro de 44°40'",Sp(2*S(44,40)))])
folha(52,U,2,'mistura das unidades 2 e 3, com minutos e segundos nos cálculos de complemento.',a,b)

# 53: unidade 4
a=page('revisão: equações com ângulos',R,[
  xi('2x − 20° = 90°. Ache x.',lambda x:2*x-110), xi('Complementares x e 8x. Ache x.',lambda x:9*x-90),
  xi('Suplementares x + 50° e x. Ache x.',lambda x:2*x-130), xi('O complemento de x é o triplo de x. Ache x.',lambda x:90-x-3*x),
  xi('O suplemento de x é 8 vezes x. Ache x.',lambda x:180-x-8*x), xi('O suplemento de x é o triplo do complemento. Ache x.',lambda x:180-x-3*(90-x)),
  ang_item('Suplementares na razão 1 : 2. O maior?',D(120)), xi('Complementares que diferem em 36°. O menor?',lambda x:2*x+36-90),
  xi('O suplemento do complemento de x é 6x. Ache x.',lambda x:90+x-6*x), xi('O complemento de x é 1/4 do suplemento. Ache x.',lambda x:90-x-(180-x)/4)])
b=page('revisão: equações com resposta em graus e minutos',R,[
  xi('O complemento de x é 5x. Ache x.',lambda x:90-6*x), xi('O suplemento de x é 3 vezes o complemento mais 10°. Ache x.',lambda x:180-x-3*(90-x)-10),
  ang_item('Complementares na razão 5 : 3. O maior?',D(Fr(450,8))), xi('Suplementares que diferem em 25°. O maior?',lambda x:2*x+25-180,ask=lambda x:x+25),
  xi('O complemento de x é igual a x + 15°. Ache x.',lambda x:90-x-(x+15))])
folha(53,U,3,'unidade 4 inteira misturada.',a,b)

# 54: unidade 5
a=page('revisão: posições',R,[
  ang_item(f'Adjacentes {nm("A","O","B")} = 37° e {nm("B","O","C")} = 58°. {nm("A","O","C")}?',D(95)),
  ang_item(f'{nm("A","O","C")} = 112°, {nm("A","O","B")} = 49°. {nm("B","O","C")}?',D(63)),
  ang_item(f'Bissetriz de 64°: cada metade?',D(32)), ang_item(f'Bissetriz de 99°: cada metade?',D(Fr(99,2))),
  ang_item('Opostos pelo vértice: um mede 123°. O outro?',D(123)), ang_item('Retas se cruzam: um ângulo mede 123°. O vizinho?',D(57)),
  xi('Opostos: 5x − 15° e 3x + 25°. Ache x.',lambda x:2*x-40), xi('Lado a lado: 2x e 7x. Ache x.',lambda x:9*x-180),
  xi('Sobre uma reta: x, 4x e 30°. Ache x.',lambda x:5*x+30-180), ang_item('Bissetrizes de adjacentes 36° e 84°: MÔN?',D(60))])
b=page('revisão: posições com figura',R,[
  bis_item('4x − 5°','2x + 25°'), cruz_eq('7x − 30°','4x + 15°','op'), cruz_eq('2x + 10°','5x + 30°','ad'),
  linha_item(['3x','x + 10°','2x + 20°'],180), linha_item(['x','2x','3x','x + 10°','3x'],360)])
folha(54,U,4,'unidade 5 inteira misturada.',a,b)

# 55: unidades 1 a 3 com figura e contas
F55='semirretas de mesma origem O: A 0°, B 25°, C 90°, D 155°, E 180°; escrever entre A e B: 25°; entre C e D: 65°; marca de ângulo reto entre A e C'
a=page('revisão: leitura de figura e complemento',R,[
  cls_item(f'Tipo de {nm("A","O","D")}',155,fig=F55), ang_item(f'Quanto mede {nm("B","O","C")}?',D(65),fig='a mesma figura'),
  ang_item(f'Quanto mede {nm("D","O","E")}?',D(25),fig='a mesma figura'), ang_item(f'Complemento de {nm("A","O","B")}',D(65),fig='a mesma figura'),
  ang_item(f'Suplemento de {nm("A","O","D")}',D(25),fig='a mesma figura')])
b=page('revisão: contas com graus, minutos e segundos',R,[
  ang_item("Complemento de 1/8 de volta",D(45)), ang_item("Suplemento do ângulo dos ponteiros às 2 h",D(120)),
  ang_item("(90° − 33°33') ÷ 2",(D(90)-S(33,33))/2), ang_item("2 × (180° − 120°20')",2*(D(180)-S(120,20))),
  ang_item("Complemento de 0,25 de 100°",D(65))])
folha(55,U,5,'mistura das unidades 1 a 3, agora com figura.',a,b)

# 56: unidades 3 e 4
a=page('revisão: das contas às equações',R,[
  ang_item('Suplemento do complemento de 72°',Sp(C(D(72)))), xi('O suplemento do complemento de x é 162°. Ache x.',lambda x:90+x-162),
  ang_item('O dobro do complemento de 18°',2*C(D(18))), xi('O dobro do complemento de x é 144°. Ache x.',lambda x:2*(90-x)-144),
  ang_item('A metade do suplemento de 40°',Sp(D(40))/2), xi('A metade do suplemento de x é 70°. Ache x.',lambda x:(180-x)/2-70),
  ang_item('Complemento do triplo de 25°',C(3*D(25))), xi('O complemento do triplo de x é 15°. Ache x.',lambda x:90-3*x-15),
  ang_item('Suplemento menos complemento de 33°',D(90)), xi('O suplemento de x é 4 vezes x. Ache x.',lambda x:180-5*x)])
b=page('revisão: equações encadeadas',R,[
  xi('O complemento do suplemento de x é x/4. Ache x.',lambda x:x-90-x/4), xi('O suplemento do complemento de x é 3x + 10°. Ache x.',lambda x:90+x-3*x-10),
  xi('O complemento de x mais o suplemento de x dá 3x. Ache x.',lambda x:270-2*x-3*x), xi('O dobro do suplemento de x é 5 vezes o complemento. Ache x.',lambda x:2*(180-x)-5*(90-x)),
  ang_item('Suplementares na razão 2 : 3. O menor?',D(72))])
folha(56,U,6,'a mesma conta nos dois sentidos: calcular direto e achar x a partir do resultado.',a,b)

# 57: unidades 4 e 5
a=page('revisão: posições que viram equação',R,[
  xi('Bissetriz: metades 3x − 10° e x + 30°. Ache x.',lambda x:2*x-40), xi('Opostos: 2x + 5° e 3x − 25°. Ache x.',lambda x:x-30),
  xi('Lado a lado: x + 15° e 2x. Ache x.',lambda x:3*x+15-180), xi('Sobre uma reta: x, x + 20°, x + 40°. Ache x.',lambda x:3*x+60-180),
  xi('Em volta de um ponto: x, 3x, 5x, 3x. Ache x.',lambda x:12*x-360), xi('Adjacentes complementares: 2x e x + 15°. Ache x.',lambda x:3*x+15-90),
  xi('Adjacentes suplementares: 4x e 5x. Ache x.',lambda x:9*x-180), xi('Opostos: x/2 + 30° e x. Ache x.',lambda x:x-x/2-30),
  xi('Bissetriz de um ângulo de 6x; cada metade mede 39°. Ache x.',lambda x:3*x-39), xi('Lado a lado: 3x e o complemento de x. Ache x.',lambda x:3*x+(90-x)-180)])
b=page('revisão: posições e equações com figura',R,[
  bis_item('5x + 3°','3x + 21°'), cruz_eq('x + 48°','4x','op'), cruz_eq('3x + 15°','x + 5°','ad'),
  linha_item(['2x','x + 15°','x + 25°'],180), linha_item(['x + 10°','2x','2x + 20°','90°'],360)])
folha(57,U,7,'mistura das unidades 4 e 5: toda posição vira uma equação.',a,b)

# 58-60: tudo
a=page('revisão geral (nível 1)',R,[
  cls_item('Classifique 3/4 de um raso',135), ang_item("71°48' + 18°12'",S(71,48)+S(18,12)), ang_item('Complemento de 66°',C(D(66))),
  xi('Complementares x e 2x + 15°. Ache x.',lambda x:3*x+15-90), ang_item('Bissetriz de 130°: cada metade?',D(65)),
  ang_item('Retas se cruzam: um ângulo mede 35°. O oposto?',D(35)), ang_item("Suplemento de 140°25'",Sp(S(140,25))),
  ang_item('Menor ângulo dos ponteiros às 10 h',D(60)), xi('O suplemento de x é 2x. Ache x.',lambda x:180-3*x), ang_item("40°30' ÷ 3",S(40,30)/3)])
b=page('revisão geral com figura (nível 1)',R,[
  bis_item('x + 12°','3x − 8°'), cruz_eq('5x','3x + 30°','op'), linha_item(['x','2x','3x'],180),
  bis2_item(50,40,'MÔN?'), ang_item(f'{nm("A","O","C")} = 95°, {nm("A","O","B")} = 38°. {nm("B","O","C")}?',D(57),fig=raios_fig([('A',0),('B',38),('C',95)],[('A','B','38°'),('A','C (o ângulo todo, arco externo)','95°')]))])
folha(58,U,8,'tudo de 1 a 50 misturado, em nível fácil.',a,b)

a=page('revisão geral (nível 2)',R,[
  ang_item("Complemento de 45°45'45\"",C(S(45,45,45))), xi('O suplemento de x é o quádruplo do complemento. Ache x.',lambda x:180-x-4*(90-x)),
  ang_item('Complemento do suplemento de 152°',C(Sp(D(152)))), xi('Opostos: 6x − 18° e 4x + 12°. Ache x.',lambda x:2*x-30),
  ang_item("Bissetriz de 75°30': cada metade?",S(75,30)/2), ang_item('Suplementares na razão 7 : 11. O menor?',D(70)),
  xi('Em volta de um ponto: 2x, 3x, 4x, 6x. Ache x.',lambda x:15*x-360), ang_item("3 × 27°47'",3*S(27,47)),
  xi('O complemento de x é 7x. Ache x.',lambda x:90-8*x), ang_item('Bissetrizes de adjacentes suplementares: MÔN?',D(90))])
b=page('revisão geral com figura (nível 2)',R,[
  bis_item('7x − 12°','4x + 15°'), cruz_eq('3x + 17°','5x + 3°','ad'), linha_item(['4x','x + 5°','2x + 10°','5x + 21°'],360),
  linha_item(['x + 7°','2x − 7°','3x'],180), bis2_item(72,108,'MÔN?')])
folha(59,U,9,'tudo de 1 a 50 misturado, em nível médio.',a,b)

a=page('revisão geral (nível 3)',R,[
  xi('O suplemento do complemento de x é 5 vezes o complemento de x. Ache x.',lambda x:90+x-5*(90-x)),
  ang_item("Suplemento do complemento de 12°34'56\"",Sp(C(S(12,34,56)))),
  xi('A soma do complemento com o suplemento de x é 4x. Ache x.',lambda x:270-2*x-4*x),
  xi('Complementares; o triplo de um é o dobro do outro. O menor?',lambda x:3*x-2*(90-x)),
  xi('Suplementares; um é o triplo do outro mais 12°. O maior?',lambda x:x+3*x+12-180,ask=lambda x:3*x+12),
  ang_item("(180° − 3 × 25°45') ÷ 2",(D(180)-3*S(25,45))/2),
  xi('Bissetriz: metades x/2 + 20° e x − 10°. Ache x.',lambda x:x/2+20-(x-10)),
  xi('Opostos pelo vértice: 2x + 30° e o suplemento de x. Ache x.',lambda x:2*x+30-(180-x)),
  xi('Sobre uma reta: o complemento de x, x e 2x. Ache x.',lambda x:(90-x)+x+2*x-180),
  ang_item('Menor ângulo dos ponteiros às 7 h, dividido por 4',D(Fr(150,4)))])
b=page('revisão geral com figura (nível 3)',R,[
  bis_item('x/2 + 22°','2x − 26°'), cruz_eq('8x − 5°','3x + 40°','op'), cruz_eq('x + 37°','4x + 8°','ad'),
  linha_item(['x','2x','3x','4x','5x','9x'],360), linha_item(['3x − 4°','x + 12°','2x + 4°'],180)])
folha(60,U,10,'tudo de 1 a 50 misturado, no nível mais alto antes das paralelas.',a,b)
