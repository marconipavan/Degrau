from common import *
from u2 import disp
U='Posições'
H='\u0302'
def nm(P,V,Q): return f'{P}{V}{H}{Q}'
def g(v):  # graus (Fraction) -> texto curto para direção
    v=Fr(v); assert v.denominator in (1,2), v; return num(v)
def raios_fig(dirs, escritas, origem='O', extra=''):
    """dirs: lista (nome, direção em graus); escritas: lista (P,Q,texto) entre semirretas"""
    t=f"semirretas de mesma origem {origem}: "+', '.join(f'{n} {g(d)}°' for n,d in dirs)
    if escritas: t+='; escrever '+'; '.join(f'entre {p} e {q}: {txt}' for p,q,txt in escritas)
    return t+(('; '+extra) if extra else '')
def verifica_expr(expr, x, alvo):
    v=eval(expr.replace('°','').replace('x','*x').replace(' ','').lstrip('*').replace('(*x','(x').replace('+*x','+x').replace('-*x','-x'), {'x':x})
    assert Fr(v)==Fr(alvo), (expr,x,v,alvo)
def ev(expr,x):  # avalia "3x + 10°", "x/2 + 5°"
    e=expr.replace('°','').replace('−','-').replace(' ','')
    import re
    e=re.sub(r'(\d)x', r'\1*x', e)
    return Fr(eval(e,{'x':x,'Fr':Fr})) if '/' not in e else Fr(eval(e.replace('x','Fr(x)'),{'x':x,'Fr':Fr}))

# 41
somas=[(30,45),(20,50),(35,35),(60,25),(15,75)]
a=page('somar ângulos adjacentes','Calcule a medida de AÔC.',
  [ang_item(f'Figura {i+1}: quanto mede {nm("A","O","C")}?',deg(p+q),
     fig=raios_fig([('A',0),('B',p),('C',p+q)],[('A','B',f'{p}°'),('B','C',f'{q}°')])) for i,(p,q) in enumerate(somas)],
  exemplo=f'{nm("A","O","B")} = 30° e {nm("B","O","C")} = 45° lado a lado: {nm("A","O","C")} = 30° + 45° = 75°.')
difs=[(100,35),(90,40),(150,60),(80,25),(120,85)]
b=page('subtrair ângulos adjacentes','Calcule a medida de BÔC.',
  [ang_item(f'Figura {i+1}: quanto mede {nm("B","O","C")}?',deg(t-p),
     fig=raios_fig([('A',0),('B',p),('C',t)],[('A','B',f'{p}°'),('A','C (o ângulo todo, arco externo)',f'{t}°')])) for i,(t,p) in enumerate(difs)],
  exemplo=f'{nm("A","O","C")} = 100° e {nm("A","O","B")} = 35°: {nm("B","O","C")} = 100° − 35° = 65°.')
folha(41,U,1,'ângulos lado a lado: o todo é a soma das partes.',a,b)

# 42
def classe_par(r1,r2,dirs):
    d=dict(dirs)
    s1={r1[0],r1[1]}; s2={r2[0],r2[1]}
    com=s1&s2
    if len(com)!=1: return 'N'
    i1=sorted([d[x] for x in s1]); i2=sorted([d[x] for x in s2])
    inter=min(i1[1],i2[1])-max(i1[0],i2[0])
    return 'A' if inter<=0 else 'C'
ACE42={'A':['adjacentes'],'C':['consecutivos'],'N':['nenhum']}
def par_items(dirs,pares,fig):
    its=[]
    for i,(p1,p2) in enumerate(pares):
        k=classe_par(p1,p2,dirs)
        its.append(item(f'{nm(p1[0],"O",p1[1])} e {nm(p2[0],"O",p2[1])}',k,ACE42[k],fig=fig if i==0 else 'a mesma figura'))
    return its
d42=[('A',0),('B',40),('C',90),('D',130)]
p42=[('AB','BC'),('AB','AC'),('AB','CD'),('BC','CD'),('AC','CD'),('AC','BD'),('AD','AB'),('AD','BD'),('AB','BD'),('AC','BC')]
a=page('classificar pares: adjacentes, consecutivos ou nenhum','Par: adjacentes (A), só consecutivos (C) ou N?',
  par_items(d42,p42,raios_fig(d42,[])),
  exemplo=f'{nm("A","O","B")} e {nm("B","O","C")}: lado OB comum, sem se sobrepor → A. {nm("A","O","B")} e {nm("A","O","C")}: lado OA comum, mas um está dentro do outro → C.')
d42b=[('P',0),('Q',50),('R',100),('S',150),('T',180)]
p42b=[('PQ','QR'),('PR','RS'),('PQ','PR'),('QS','ST'),('PQ','RS'),('PT','QT'),('QR','RT'),('PS','QR'),('RS','ST'),('PR','QR')]
p42b=[(a1,a2) for a1,a2 in p42b]
def par_items2(dirs,pares,fig):
    its=[]
    for i,(p1,p2) in enumerate(pares):
        k=classe_par(p1,p2,dirs)
        its.append(item(f'{nm(p1[0],"O",p1[1])} e {nm(p2[0],"O",p2[1])}',k,ACE42[k],fig=fig if i==0 else 'a mesma figura'))
    return its
b=page('classificar pares numa figura com 5 semirretas','Par: adjacentes (A), só consecutivos (C) ou N?',
  par_items2(d42b,p42b,raios_fig(d42b,[])))
folha(42,U,2,'nomes das posições: consecutivos (lado comum) e adjacentes (lado comum sem sobrepor).',a,b)

# 43
v43=[70,50,90,120,36,75,45,101,13,179]
a=page('bissetriz: metade do ângulo','OM é bissetriz de AÔB. Calcule AÔM.',
  [ang_item(f'{nm("A","O","B")} = {v}°',deg(Fr(v,2)),fig=raios_fig([('A',0),('M',Fr(v,2)),('B',v)],[('A','B (o ângulo todo, arco externo)',f'{v}°')]) if i<2 else None) for i,v in enumerate(v43)],
  exemplo=f'OM é bissetriz de {nm("A","O","B")} = 70°: divide ao meio, {nm("A","O","M")} = 35°.')
v43b=[S(50,20),S(31,10),S(45,15),S(100,30),S(1,0)]
b=page('bissetriz com minutos e segundos','OM é bissetriz de AÔB. Calcule AÔM.',
  [ang_item(f'{nm("A","O","B")} = {disp(x)}',x/2) for x in v43b],
  exemplo=f"{nm('A','O','B')} = 31°10': metade = 15°35'.")
folha(43,U,3,'bissetriz: a semirreta que divide o ângulo ao meio.',a,b)

# 44
def bis_item(e1,e2,ask='x'):
    x=solve(lambda x:ev(e1,x)-ev(e2,x)); h=ev(e1,x); assert h>0 and h<180
    fig=raios_fig([('A',0),('M',h),('B',2*h)],[('A','M',e1),('M','B',e2)])
    v= x if ask=='x' else 2*h
    q='Ache x.' if ask=='x' else f'Quanto mede {nm("A","O","B")}?'
    return ang_item(f'{nm("A","O","M")} = {e1} e {nm("M","O","B")} = {e2}. {q}',deg(v),fig=fig)
from u4 import solve
a=page('bissetriz com expressões: achar x','OM é bissetriz de AÔB. Ache x.',[
  bis_item('2x + 10°','3x − 5°'), bis_item('x + 20°','2x'), bis_item('4x − 10°','2x + 30°'),
  bis_item('3x','x + 40°'), bis_item('5x − 20°','3x + 10°')],
  exemplo='As duas metades são iguais: 2x + 10° = 3x − 5° → x = 15°.')
b=page('bissetriz com expressões: achar o ângulo todo','OM é bissetriz. Quanto mede AÔB?',[
  bis_item('2x + 10°','3x − 5°','todo'), bis_item('x + 25°','2x + 5°','todo'), bis_item('3x − 15°','x + 25°','todo'),
  bis_item('6x','4x + 12°','todo'), bis_item('x + 30°','3x − 10°','todo')],
  exemplo='2x + 10° = 3x − 5° → x = 15°; cada metade mede 40°; AÔB = 80°.')
folha(44,U,4,'bissetriz com expressões em x.',a,b)

# 45
def cruz_fig(t, escr):
    """escr: dict com chaves 'd','c','e','b' (direita: entre 0° e t; cima: entre t e 180°; esquerda: entre 180° e t+180°; baixo: entre t+180° e 360°)"""
    nomes={'d':f'entre 0° e {t}°','c':f'entre {t}° e 180°','e':f'entre 180° e {t+180}°','b':f'entre {t+180}° e 360°'}
    s=f'retas que se cruzam no ponto O, nas direções 0° (e 180°) e {t}° (e {t+180}°); escrever '
    return s+'; '.join(f'no ângulo {nomes[k]}: {v}' for k,v in escr.items())+'; nos outros, nada'
tt=[40,65,110,25,135]
a=page('opostos pelo vértice: valores','Ache x (ângulos opostos pelo vértice).',
  [ang_item(f'Figura {i+1}',deg(t),fig=cruz_fig(t,{'d':f'{t}°','e':'x'})) for i,t in enumerate(tt)],
  exemplo='Duas retas se cruzam: os ângulos opostos (de frente um para o outro) são iguais. 40° e x opostos → x = 40°.')
tt2=[50,70,120,30,145]
b=page('ângulos lado a lado nas retas que se cruzam','Ache x (lado a lado somam 180°).',
  [ang_item(f'Figura {i+1}',deg(180-t),fig=cruz_fig(t,{'d':f'{t}°','c':'x'})) for i,t in enumerate(tt2)],
  exemplo='Lado a lado sobre a mesma reta: 50° + x = 180° → x = 130°.')
folha(45,U,5,'duas retas que se cruzam: opostos iguais.',a,b)

# 46
def cruz_eq(e1,e2,tipo,t_ask='x'):
    if tipo=='op': x=solve(lambda x:ev(e1,x)-ev(e2,x)); t=ev(e1,x); escr={'d':e1,'e':e2}
    else: x=solve(lambda x:ev(e1,x)+ev(e2,x)-180); t=ev(e1,x); escr={'d':e1,'c':e2}
    assert 0<t<180 and t.denominator==1, (e1,e2,t)
    return ang_item(f'{e1} e {e2}',deg(x),fig=cruz_fig(int(t),escr))
a=page('opostos pelo vértice com expressões','Ache x (opostos pelo vértice).',[
  cruz_eq('3x + 10°','5x − 30°','op'), cruz_eq('2x + 15°','x + 40°','op'), cruz_eq('4x','2x + 50°','op'),
  cruz_eq('6x − 20°','3x + 25°','op'), cruz_eq('x + 70°','3x + 10°','op')],
  exemplo='3x + 10° = 5x − 30° → 40° = 2x → x = 20°.')
b=page('lado a lado com expressões','Ache x (lado a lado somam 180°).',[
  cruz_eq('2x + 30°','4x','ad'), cruz_eq('x + 20°','3x','ad'), cruz_eq('5x','4x + 18°','ad'),
  cruz_eq('3x − 10°','2x + 40°','ad'), cruz_eq('x','x + 60°','ad')],
  exemplo='2x + 30° + 4x = 180° → 6x = 150° → x = 25°.')
folha(46,U,6,'retas que se cruzam com expressões em x.',a,b)

# 47
def linha_item(exprs, total):
    x=solve(lambda x:sum(ev(e,x) for e in exprs)-total)
    vals=[ev(e,x) for e in exprs]; assert all(v>0 for v in vals)
    nomes='ABCDEFG'; dirs=[]; acc=Fr(0)
    for i,v in enumerate(vals): dirs.append((nomes[i],acc)); acc+=v
    if total==180: dirs.append((nomes[len(vals)],acc))
    esc=[(nomes[i],nomes[i+1] if (i+1<len(vals) or total==180) else nomes[0],e) for i,e in enumerate(exprs)]
    extra='A e '+nomes[len(vals)]+' formam uma reta' if total==180 else 'as semirretas dão a volta completa em O'
    return ang_item(' , '.join(exprs).replace(' , ',', '),deg(x),fig=raios_fig(dirs,esc,extra=extra))
a=page('ângulos em sequência sobre uma reta (somam 180°)','Os ângulos formam um raso. Ache x.',[
  linha_item(['x','2x','30°'],180), linha_item(['x','x','x'],180), linha_item(['2x','3x','x + 30°'],180),
  linha_item(['x + 10°','x + 20°','x + 30°'],180), linha_item(['4x','x','45°'],180)],
  exemplo='x, 2x e 30° lado a lado sobre uma reta: x + 2x + 30° = 180° → x = 50°.')
b=page('ângulos em volta de um ponto (somam 360°)','Os ângulos dão a volta toda. Ache x.',[
  linha_item(['x','2x','3x','4x'],360), linha_item(['x','x','x','x'],360), linha_item(['2x','3x','100°'],360),
  linha_item(['x + 20°','x + 40°','2x'],360), linha_item(['5x','90°','3x','x'],360)],
  exemplo='x, 2x, 3x e 4x em volta de O: 10x = 360° → x = 36°.')
folha(47,U,7,'vários ângulos em sequência: somam 180° (reta) ou 360° (volta).',a,b)

# 48
def bis2_item(p,q,ask_txt):
    dirs=[('A',0),('M',Fr(p,2)),('B',p),('N',p+Fr(q,2)),('C',p+q)]
    return ang_item(f'{nm("A","O","B")} = {p}° e {nm("B","O","C")} = {q}°. {ask_txt}',deg(Fr(p+q,2)),
        fig=raios_fig(dirs,[('A','B',f'{p}°'),('B','C',f'{q}°')],extra='OM e ON tracejadas'))
a=page('ângulo entre as bissetrizes de dois adjacentes','OM e ON são bissetrizes. Quanto mede MÔN?',[
  bis2_item(40,80,'MÔN?'), bis2_item(30,50,'MÔN?'), bis2_item(60,60,'MÔN?'), bis2_item(20,100,'MÔN?'), bis2_item(70,45,'MÔN?')],
  exemplo='AÔB = 40°, BÔC = 80°: MÔB = 20°, BÔN = 40°, MÔN = 60° (metade da soma).')
b=page('bissetrizes de adjacentes suplementares ou complementares','OM e ON são bissetrizes. Quanto mede MÔN?',[
  bis2_item(50,130,'MÔN?'), bis2_item(100,80,'MÔN?'), bis2_item(30,60,'MÔN?'), bis2_item(15,165,'MÔN?'), bis2_item(45,45,'MÔN?')])
folha(48,U,8,'duas bissetrizes ao mesmo tempo: o ângulo entre elas é a metade da soma.',a,b)

# 49
a=page('mistura de posições com x','Ache x.',[
  bis_item('3x + 5°','4x − 10°'), cruz_eq('5x − 10°','2x + 50°','op'), cruz_eq('3x + 20°','x','ad'),
  linha_item(['x','3x','2x'],180), linha_item(['x + 30°','2x + 30°','3x'],360)])
b=page('mistura de posições: achar o ângulo','Calcule o que se pede.',[
  bis_item('2x + 20°','5x − 10°','todo'),
  ang_item(f'Retas se cruzam; um ângulo mede 2x e o oposto, x + 35°. Quanto mede 2x?',deg(70),fig=cruz_fig(70,{'d':'2x','e':'x + 35°'})),
  bis2_item(64,116,'MÔN?'),
  ang_item('Retas se cruzam; dois ângulos lado a lado: 3x e 2x. Quanto mede o maior?',deg(108),fig=cruz_fig(108,{'d':'3x','c':'2x'})),
  ang_item(f'Sobre uma reta: x, x e x + 30°. Quanto mede o maior?',deg(80),fig=raios_fig([('A',0),('B',50),('C',100),('D',180)],[('A','B','x'),('B','C','x'),('C','D','x + 30°')],extra='A e D formam uma reta'))])
folha(49,U,9,'reconhecer sozinho qual posição usar (bissetriz, opostos, reta, volta).',a,b)

# 50
a=page('revisão da unidade','Revisão: responda no caderno.',[
  ang_item(f'{nm("A","O","B")} = 28° e {nm("B","O","C")} = 47°, adjacentes. {nm("A","O","C")}?',deg(75)),
  ang_item(f'{nm("A","O","C")} = 130° e {nm("A","O","B")} = 55°, adjacentes. {nm("B","O","C")}?',deg(75)),
  ang_item(f'OM bissetriz de {nm("A","O","B")} = 86°. {nm("A","O","M")}?',deg(43)),
  ang_item(f"OM bissetriz de {nm('A','O','B')} = 47°. {nm('A','O','M')}?",deg(Fr(47,2))),
  ang_item('Retas se cruzam; um ângulo mede 72°. O oposto?',deg(72)),
  ang_item('Retas se cruzam; um ângulo mede 72°. O vizinho?',deg(108)),
  ang_item('Opostos pelo vértice: 4x − 20° e 2x + 30°. Ache x.',deg(25)),
  ang_item('Sobre uma reta: x, 2x, 3x. Ache x.',deg(30)),
  ang_item('Em volta de um ponto: x, 2x, 3x, 6x. Ache x.',deg(30)),
  ang_item('Bissetrizes de adjacentes de 50° e 70°: MÔN?',deg(60))])
b=page('revisão com figura','Revisão: ache x.',[
  bis_item('x + 15°','2x − 5°'), cruz_eq('4x − 20°','2x + 30°','op'), cruz_eq('x + 10°','2x + 20°','ad'),
  linha_item(['x','x + 20°','2x'],180), linha_item(['3x','2x','4x','x + 10°'],360)])
folha(50,U,10,'revisão de toda a unidade (nada novo).',a,b)
