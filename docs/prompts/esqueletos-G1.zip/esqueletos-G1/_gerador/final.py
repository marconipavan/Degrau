import sys, os, zipfile
sys.path.insert(0,'/home/claude/esq')
from common import *
import u1,u2,u3,u4,u5,u6,u7,u8,u9,u10
from u5 import cruz_fig
from u8 import pq
from u9 import bico_item
from u7 import fig_par
for n in sorted(FOLHAS): escreve(FOLHAS[n])
falt=[n for n in range(1,101) if n not in FOLHAS and n not in (1,2,3,81,85,89)]
assert not falt, falt

# ---------- nivelamento ----------
f8=pq(0,{4:'3x + 50°',5:'2x + 30°'})
f9=bico_item([-20,-150,-40],('dir','esq'),2)
f5=cruz_fig(55,{'d':'3x + 10°','e':'5x − 20°'})
Q=[
 ('Reconhecer ângulos','G1 1', item('Classifique o ângulo de 135°: agudo (A), reto (R), obtuso (O) ou raso (Ra).','O',['obtuso'])),
 ('Graus, minutos e segundos','G1 11', ang_item("Calcule 35°40' + 24°35'.",S(35,40)+S(24,35))),
 ('Complemento e suplemento','G1 21', ang_item('Calcule o complemento do suplemento de 130°.',deg(40))),
 ('Equações com ângulos','G1 31', ang_item('O suplemento de x é o triplo do complemento de x. Ache x.',deg(45))),
 ('Posições','G1 41', ang_item('Duas retas se cruzam. Os ângulos opostos pelo vértice medem 3x + 10° e 5x − 20°. Ache x.',deg(15),fig=f5)),
 ('Revisão 1','G1 51', ang_item("Calcule a metade do complemento de 36°40'.",(deg(90)-S(36,40))/2)),
 ('Paralelas: identificar','G1 61', item('Na figura, r // s. Qual é o alterno interno do ângulo 3?','5',fig=fig_par(60))),
 ('Paralelas: calcular','G1 71', dict(f8, enun='Na figura, r // s. Ache x.')),
 ('O bizu dos bicos','G1 81', dict(f9, enun='Na figura, r // s. Ache x.')),
 ('Questões de prova','G1 91', item('Dois ângulos complementares estão na razão 2 : 3. O maior mede: (A) 36° (B) 54° (C) 60° (D) 72°','B',['54°','54'])),
]
L=['# Prova de nivelamento — G1 (Ângulos)','',
 'Para que serve: definir em que folha cada aluno entra no nível G1.','',
 'Como aplicar: 10 questões, uma por unidade, na ordem das unidades e da mais fácil para a mais difícil. Cada uma deve sair em 1 a 2 minutos; a prova toda em cerca de 15 minutos. Resposta curta, resolvida no caderno e enviada pelo formulário (código do bloco: `G1 NIV`).','',
 'Pontos: 10 cada.','',
 'Regra de entrada: olhe a **primeira questão errada**. O aluno entra na **primeira folha da unidade dessa questão** (coluna "Entrada"), que fica um pouco abaixo de onde ele começou a errar. Se acertar as 10, entra em G1 91 (questões de prova) e faz o nivelamento do G2 quando ele existir. Se errar a questão 1, entra em G1 1.','',
 'Itens:']
for i,(u,ent,it) in enumerate(Q,1):
    parts=[f"Unidade: {u}",f"Entrada se for a primeira errada: {ent}",f"Enunciado: {it['enun']}"]
    if it.get('fig'): parts.append(f"Figura: {it['fig']}")
    parts.append(f"Resposta: {it['resp']}")
    if it.get('aceitar'): parts.append('Aceitar também: '+'; '.join(it['aceitar']))
    L.append(f'{i}. '+' | '.join(parts))
open(os.path.join(OUT,'NIVELAMENTO_G1.md'),'w').write('\n'.join(L)+'\n')
print('nivelamento: x8 =',f8['resp'],' x9 =',f9['resp'])

# ---------- índice ----------
EXIST={1:('Reconhecer ângulos 1','nomear ângulos e classificar valores (já existe)'),
       2:('Reconhecer ângulos 2','classificar pela figura e listar ângulos de semirretas (já existe)'),
       3:('Reconhecer ângulos 3','tipo a partir de uma conta; revisão de 1 a 3 (já existe)'),
       81:('O bizu dos bicos 1','um bico: o ângulo do bico é a soma dos ângulos nas paralelas (já existe)'),
       85:('O bizu dos bicos 5','dois bicos: somas dos que abrem para cada lado são iguais (já existe)'),
       89:('O bizu dos bicos 9','expressões em x e questão de prova (já existe)')}
I=['# Índice — G1 (Ângulos)','','| Folha | Unidade | Degrau novo |','|---|---|---|']
for n in range(1,101):
    if n in EXIST: u,dg=EXIST[n]
    else: f=FOLHAS[n]; u=f"{f['unidade']} {f['pos']}"; dg=f['degrau']
    I.append(f'| G1 {n} | {u} | {dg} |')
I+=['','Nivelamento: `NIVELAMENTO_G1.md` (10 questões, uma por unidade).']
open(os.path.join(OUT,'INDICE.md'),'w').write('\n'.join(I)+'\n')

# ---------- estatísticas e zip ----------
tot=0
for n,f in FOLHAS.items():
    for l in 'ab': tot+=len(f[l]['itens'])
print('folhas:',len(FOLHAS),'itens:',tot)
z='/mnt/user-data/outputs/esqueletos-G1.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as zz:
    for fn in sorted(os.listdir(OUT)): zz.write(os.path.join(OUT,fn),'esqueletos-G1/'+fn)
print(len(os.listdir(OUT)),'arquivos no zip')
