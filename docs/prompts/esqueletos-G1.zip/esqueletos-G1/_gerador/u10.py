from common import *
from u2 import disp
from u4 import solve
from u5 import bis_item, cruz_eq, linha_item, raios_fig, cruz_fig, nm
from u8 import pq
from u9 import bico_item, R, Lf
U='Questões de prova'
FONTE='inédita, no estilo EPCAR/Colégio Naval'
_k=[0]
def A(sec):  # texto de alternativa
    c=fmt(sec)[0]; return c+'°' if c.isdigit() else c
def mc(enun, correta, erradas, fig=None, letra=None):
    alts=[A(e) if not isinstance(e,str) else e for e in erradas]
    cor=A(correta) if not isinstance(correta,str) else correta
    assert cor not in alts and len(set(alts))==3, (enun,cor,alts)
    pos = letra if letra is not None else _k[0]%4; _k[0]+=1
    alts=alts[:pos]+[cor]+alts[pos:]
    if fig in CALC and not enun.startswith('Na figura, r // s. O valor de x + y'):
        assert CALC[fig] in (cor, cor.rstrip('°')), ('figura não bate', enun, CALC[fig], cor)
    return item(enun,'ABCD'[pos],[],fig=fig,alts=alts,fonte=FONTE)
CALC={}
def from_it(it):
    CALC[it['fig']]=it['resp']; return it['fig'], it['resp']
D=deg; C=lambda x:D(90)-x; Sp=lambda x:D(180)-x
def P(n):
    return {2:'50 cada',3:'34 na 1ª; 33 nas outras'}[n]

# 91
a=page('questões de prova: complemento e suplemento','Marque a alternativa correta.',[
  mc("O suplemento do complemento de um ângulo de 35°20' mede:",Sp(C(S(35,20))),[C(S(35,20)),Sp(S(35,20)),S(55,20)]),
  mc('O suplemento de um ângulo agudo excede o seu complemento em:',D(90),[D(45),D(180),'um valor que depende do ângulo'])],pontos=P(2))
b=page('questões de prova: equações com ângulos','Marque a alternativa correta.',[
  mc('Um ângulo cujo suplemento é o triplo do seu complemento mede:',D(45),[D(30),D(60),D(135)]),
  mc('Dois ângulos complementares estão na razão 2 : 7. O maior deles mede:',D(70),[D(20),D(140),D(63)])],pontos=P(2))
folha(91,U,1,'primeiro contato com o formato de prova (alternativas), em complemento e suplemento.',a,b)

# 92
a=page('questões de prova: graus, minutos e segundos','Marque a alternativa correta.',[
  mc("O valor de 90° − 2 × 23°45' é:",D(90)-2*S(23,45),[S(66,15),S(43,30),S(47,30)]),
  mc('A metade do complemento de 31° mede:',C(D(31))/2,[S(29,5),D(30),S(74,30)])],pontos=P(2))
b=page('questões de prova: operações com ângulos','Marque a alternativa correta.',[
  mc("Se α = 42°38'15\" e β = 17°21'45\", então α + β vale:",S(42,38,15)+S(17,21,45),[S(59),S(60,30),S(61)]),
  mc("1/8 de volta somado a 22°30' resulta em:",D(45)+S(22,30),[S(67,0),S(57,30),S(112,30)])],pontos=P(2))
folha(92,U,2,'formato de prova com graus, minutos e segundos.',a,b)

# 93
f1,_=from_it(bis_item('2x + 18°','4x − 12°','todo'))
f2,_=from_it(cruz_eq('3x + 25°','5x − 15°','op'))
a=page('questões de prova: posições','Marque a alternativa correta.',[
  mc(f'Na figura, OM é bissetriz de {nm("A","O","B")}. A medida de {nm("A","O","B")} é:',D(96),[D(48),D(15),D(90)],fig=f1),
  mc('Na figura, duas retas se cruzam em O. O valor de x é:',D(20),[D(85),D(40),D(10)],fig=f2)],pontos=P(2))
b=page('questões de prova: bissetrizes e ângulos sobre uma reta','Marque a alternativa correta.',[
  mc('O ângulo formado pelas bissetrizes de dois ângulos adjacentes e suplementares mede:',D(90),[D(45),D(180),'depende dos ângulos']),
  mc('Três ângulos adjacentes formam um ângulo raso e medem x, 2x + 10° e 3x − 10°. O maior mede:',D(80),[D(30),D(70),D(60)])],pontos=P(2))
folha(93,U,3,'formato de prova em posições (bissetriz, opostos, ângulos sobre uma reta).',a,b)

# 94
g1,_=from_it(pq(0,{1:'3x + 10°',5:'5x − 30°'}))
g2,_=from_it(pq(0,{4:'2x + 60°',5:'3x + 10°'}))
a=page('questões de prova: paralelas','Marque a alternativa correta (r // s).',[
  mc('Na figura, as retas r e s são paralelas. O valor de x é:',D(20),[D(70),D(25),D(10)],fig=g1),
  mc('Na figura, r // s. O valor de x é:',D(22),[D(26),D(76),D(30)],fig=g2)],pontos=P(2))
g3,_=from_it(pq(0,{1:'2x + 30°',5:'110°',6:'y'},ask='y'))
b=page('questões de prova: paralelas com duas incógnitas','Marque a alternativa correta (r // s).',[
  mc('Na figura, r // s. O valor de x + y é:',D(110),[D(40),D(150),D(70)],fig=g3),
  mc('Dois ângulos colaterais internos medem 3x + 20° e 2x + 10°. O menor deles mede:',D(70),[D(30),D(110),D(90)])],pontos=P(2))
folha(94,U,4,'formato de prova em paralelas cortadas por transversal.',a,b)

# 95
h1,_=from_it(bico_item([-38,-133],('dir','dir'),1))
h2,_=from_it(bico_item([-25,-150,-40],('dir','esq'),2))
a=page('questões de prova: bicos','Marque a alternativa correta (r // s).',[
  mc('Na figura, r // s. O valor de x é:',D(85),[D(95),D(47),D(76)],fig=h1),
  mc('Na figura, r // s. O valor de x é:',D(70),[D(95),D(55),D(40)],fig=h2)],pontos=P(2))
h3,_=from_it(bico_item([-30,-130],('dir','dir'),None,exprs={0:'x + 10°',1:'4x',2:'2x + 10°'}))
h4,_=from_it(bico_item([-25,-150,-35,-145],('dir','dir'),2))
b=page('questões de prova: bicos com expressões','Marque a alternativa correta (r // s).',[
  mc('Na figura, r // s. O valor de x é:',D(20),[D(80),D(30),D(25)],fig=h3),
  mc('Na figura, r // s. O valor de x é:',D(65),[D(55),D(70),D(115)],fig=h4)],pontos=P(2))
folha(95,U,5,'formato de prova no bizu dos bicos.',a,b)

# 96
a=page('questões de prova: relógio e frações de volta','Marque a alternativa correta.',[
  mc('O suplemento do menor ângulo formado pelos ponteiros às 4 h em ponto mede:',D(60),[D(120),D(30),D(150)]),
  mc('O complemento de 1/5 de um ângulo raso mede:',D(54),[D(36),D(144),D(18)])],pontos=P(2))
b=page('questões de prova: classificação e medida','Marque a alternativa correta.',[
  mc('O dobro do complemento de um ângulo de 25° é um ângulo:','obtuso',['agudo','reto','raso']),
  mc('Três quartos de um ângulo raso, menos um reto, mede:',D(45),[D(135),D(90),D(225)])],pontos=P(2))
folha(96,U,6,'formato de prova misturando reconhecimento de ângulos com contas.',a,b)

# 97
a=page('questões de prova: equações mais longas','Marque a alternativa correta.',[
  mc('O complemento do suplemento de um ângulo é igual à quarta parte desse ângulo. O ângulo mede:',D(120),[D(30),D(60),D(150)]),
  mc('A diferença entre o suplemento de um ângulo e o triplo do seu complemento é 20°. O ângulo mede:',D(55),[D(35),D(45),D(65)])],pontos=P(2))
b=page('questões de prova: equações com dois ângulos','Marque a alternativa correta.',[
  mc('Dois ângulos são suplementares e o triplo de um é igual ao dobro do outro. O menor mede:',D(72),[D(108),D(36),D(60)]),
  mc('O suplemento do complemento de um ângulo é 7 vezes esse ângulo. O ângulo mede:',D(15),[D(75),D(30),D(105)])],pontos=P(2))
folha(97,U,7,'formato de prova com equações de mais de um termo.',a,b)

# 98
k1,_=from_it(pq(0,{1:'2x + 20°',6:'3x + 10°'}))
k2,_=from_it(bico_item([-150,-32,-145],('esq','dir'),None,exprs={0:'3x + 9°',1:'9x − 1°',2:'10x − 3°',3:'5x'}))
a=page('questões de prova: paralelas e bicos','Marque a alternativa correta (r // s).',[
  mc('Na figura, r // s. O valor de x é:',D(30),[D(26),D(20),D(80)],fig=k1),
  mc('Na figura, r // s. O valor de x é:',D(7),[D(5),D(9),D(35)],fig=k2)],pontos=P(2))
k3,_=from_it(pq(0,{1:'3x − 46°',6:'2x − 24°'},ask=8))
b=page('questões de prova: achar um ângulo da figura','Marque a alternativa correta (r // s).',[
  mc('Na figura, r // s. O ângulo em s, abaixo à direita, mede:',D(76),[D(50),D(104),D(100)],fig=k3),
  mc('Uma transversal corta duas paralelas. Um dos 8 ângulos mede 38°. Quantos dos 8 ângulos medem 142°?','4',['2','3','1'])],pontos=P(2))
folha(98,U,8,'formato de prova com figuras que pedem passar por um terceiro ângulo.',a,b)

# 99
a=page('questões de prova: respostas em graus e minutos','Marque a alternativa correta.',[
  mc('O complemento de um ângulo é a quinta parte do seu suplemento. O ângulo mede:',D(Fr(135,2)),[S(22,30),S(67,0),S(72,30)]),
  mc('Dois ângulos suplementares diferem em 37°. O maior mede:',D(Fr(217,2)),[S(71,30),D(109),S(126,30)])],pontos=P(2))
b=page('questões de prova: bissetriz e minutos','Marque a alternativa correta.',[
  mc("A bissetriz de um ângulo de 75°30' forma com cada lado um ângulo de:",S(37,45),[S(37,15),S(37,30),S(151,0)]),
  mc("O complemento da metade de 50°20' mede:",C(S(50,20)/2),[S(39,50),S(25,10),S(65,10)])],pontos=P(2))
folha(99,U,9,'formato de prova com respostas em graus e minutos.',a,b)

# 100
m1,_=from_it(bico_item([-25,-150,-40],('dir','esq'),None,exprs={0:'2x + 5°',1:'5x + 5°',2:'7x',3:'4x'}))
a=page('simulado final (parte 1)','Marque a alternativa correta.',[
  mc('O suplemento do triplo do complemento de 70° mede:',Sp(3*C(D(70))),[D(60),D(150),D(20)]),
  mc("O valor de (180° − 47°36') ÷ 2 é:",(D(180)-S(47,36))/2,[S(66,48),S(67,12),S(132,24)]),
  mc('Na figura, r // s. O valor de x é:',D(10),[D(5),D(15),D(25)],fig=m1)],pontos=P(3))
m2,_=from_it(pq(0,{4:'x + 74°',5:'2x + 22°'}))
b=page('simulado final (parte 2)','Marque a alternativa correta.',[
  mc('O complemento de um ângulo é igual a x/2 + 15°, e o ângulo mede x. Então x vale:',D(50),[D(40),D(60),D(25)]),
  mc('Na figura, r // s. O valor de x é:',D(28),[D(32),D(26),D(102)],fig=m2),
  mc('Em volta de um ponto há quatro ângulos: x, 2x, 3x e 4x. O maior mede:',D(144),[D(36),D(108),D(160)])],pontos=P(3))
folha(100,U,10,'simulado final do nível: um pouco de cada unidade, no formato de prova.',a,b)
