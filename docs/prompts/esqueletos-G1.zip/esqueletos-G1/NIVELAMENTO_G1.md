# Prova de nivelamento — G1 (Ângulos)

Para que serve: definir em que folha cada aluno entra no nível G1.

Como aplicar: 10 questões, uma por unidade, na ordem das unidades e da mais fácil para a mais difícil. Cada uma deve sair em 1 a 2 minutos; a prova toda em cerca de 15 minutos. Resposta curta, resolvida no caderno e enviada pelo formulário (código do bloco: `G1 NIV`).

Pontos: 10 cada.

Regra de entrada: olhe a **primeira questão errada**. O aluno entra na **primeira folha da unidade dessa questão** (coluna "Entrada"), que fica um pouco abaixo de onde ele começou a errar. Se acertar as 10, entra em G1 91 (questões de prova) e faz o nivelamento do G2 quando ele existir. Se errar a questão 1, entra em G1 1.

Itens:
1. Unidade: Reconhecer ângulos | Entrada se for a primeira errada: G1 1 | Enunciado: Classifique o ângulo de 135°: agudo (A), reto (R), obtuso (O) ou raso (Ra). | Resposta: O | Aceitar também: obtuso
2. Unidade: Graus, minutos e segundos | Entrada se for a primeira errada: G1 11 | Enunciado: Calcule 35°40' + 24°35'. | Resposta: 60°15' | Aceitar também: 60°15'0"; 60°15'00"
3. Unidade: Complemento e suplemento | Entrada se for a primeira errada: G1 21 | Enunciado: Calcule o complemento do suplemento de 130°. | Resposta: 40 | Aceitar também: 40°
4. Unidade: Equações com ângulos | Entrada se for a primeira errada: G1 31 | Enunciado: O suplemento de x é o triplo do complemento de x. Ache x. | Resposta: 45 | Aceitar também: 45°
5. Unidade: Posições | Entrada se for a primeira errada: G1 41 | Enunciado: Duas retas se cruzam. Os ângulos opostos pelo vértice medem 3x + 10° e 5x − 20°. Ache x. | Figura: retas que se cruzam no ponto O, nas direções 0° (e 180°) e 55° (e 235°); escrever no ângulo entre 0° e 55°: 3x + 10°; no ângulo entre 180° e 235°: 5x − 20°; nos outros, nada | Resposta: 15 | Aceitar também: 15°
6. Unidade: Revisão 1 | Entrada se for a primeira errada: G1 51 | Enunciado: Calcule a metade do complemento de 36°40'. | Resposta: 26°40' | Aceitar também: 26°40'0"; 26°40'00"
7. Unidade: Paralelas: identificar | Entrada se for a primeira errada: G1 61 | Enunciado: Na figura, r // s. Qual é o alterno interno do ângulo 3? | Figura: retas r (acima) e s (abaixo) horizontais e paralelas; transversal t com direção 60°; escrever: em r, acima à direita: 1; em r, acima à esquerda: 2; em r, abaixo à esquerda: 3; em r, abaixo à direita: 4; em s, acima à direita: 5; em s, acima à esquerda: 6; em s, abaixo à esquerda: 7; em s, abaixo à direita: 8 | Resposta: 5
8. Unidade: Paralelas: calcular | Entrada se for a primeira errada: G1 71 | Enunciado: Na figura, r // s. Ache x. | Figura: retas r (acima) e s (abaixo) horizontais e paralelas; transversal t com direção 70°; escrever: em r, abaixo à direita: 3x + 50°; em s, acima à direita: 2x + 30°; nos outros, nada | Resposta: 20 | Aceitar também: 20°
9. Unidade: O bizu dos bicos | Entrada se for a primeira errada: G1 81 | Enunciado: Na figura, r // s. Ache x. | Figura: bico entre paralelas: retas r (acima) e s (abaixo) horizontais, distância 45 mm; poligonal começa em r; segmentos nas direções −20° (15 mm), −150° (15 mm), −40° (até s); escrever em r (início), lado direito: 20°; no vértice 1: 50°; no vértice 2: x; em s (fim), lado esquerdo: 40° | Resposta: 70 | Aceitar também: 70°
10. Unidade: Questões de prova | Entrada se for a primeira errada: G1 91 | Enunciado: Dois ângulos complementares estão na razão 2 : 3. O maior mede: (A) 36° (B) 54° (C) 60° (D) 72° | Resposta: B | Aceitar também: 54°; 54
